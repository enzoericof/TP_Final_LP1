/*
 * preparacion.h
 *
 *  Created on: 21 oct. 2023
 *      Author: lp1-2023
 */

#ifndef PREPARACION_H_
#define PREPARACION_H_

int PrimerJugador();
int ColorDado();
void mensajesPrevios (int inicia, int color);
int leerArchivo(const char *rutaArchivo, int *tipo_jugada, char *caracter, int *numero);

#endif /* PREPARACION_H_ */
