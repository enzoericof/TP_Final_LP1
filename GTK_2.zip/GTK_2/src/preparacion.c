#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h> //librería necesaria para generar números aleatorios
#include "constantes.h"

//Pide al usuario que decida quien inicia el juego (1 usuario, 2 computadora o 3 aleatorio) y retorna ese valor
int PrimerJugador()
{
    int inicia, ret;
    do {
        GREEN;printf("ELIGE QUIEN INICIA\n");
        BLA;printf("1 si inicia el usuario, 2 si inicia la computadora o 3 si quieres al azar: ");
        ret=scanf("%d", &inicia);
        while (getchar() != '\n');
    } while ( ret != 1 || (inicia < 1 || inicia > 3));
    if (inicia==3){
        srand(time(NULL));
        inicia=1+rand()%2-1+1;
    }
    return inicia;
}

//pide al usuario que decida el color del dado (1 rojo, 2 azul o 3 aleatorio) y retorna ese valor
int ColorDado()
{
    int color, ret;
    do {
        GREEN;printf("ELIGE COLOR DE DADO\n");
        BLA;printf("1 si quieres ");RED;printf("ROJO");
        BLA;printf(", 2 si quieres ");BLUE;printf("AZUL");
        BLA;printf(", 3 si quieres al azar: ");
        ret=scanf("%d", &color);
        while (getchar() != '\n');
    } while ( ret!=1 || (color < 1 || color > 3));
    if (color==3){
        srand(time(NULL));
        color=1+rand()%2-1+1;
    }
    return color;
}

//condicionales previas
void mensajesPrevios (int inicia, int color){
    GREEN;printf("\nCONFIGURACIÓN DEL JUEGO\n");BLA;
    if (inicia==1)
    {
        printf("Inicia el usuario");
    }
    else
    {
        printf("Inicia la computadora");
    }
    if(color==1)
    {
        BLA;printf("\nEl usuario juega con el dado ");RED;printf("ROJO");
        BLA;printf("\nY la computadora con el dado ");BLUE;printf("AZUL");
    }
    else
    {
        BLA;printf("\nEl usuario juega con el dado ");BLUE;printf("AZUL");
        BLA;printf("\nY la computadora con el dado ");RED;printf("ROJO");
    }
    BLA;printf("\n \nPresione enter para iniciar el juego\n");
    getchar();
    //while (getchar() != '\n');
}

//leer archivo de jugadas de máquina contraria
int leerArchivo(const char *nombreArchivo, int *tipo_jugada, char *caracter, int *numero) {
    FILE *archivo;

    // Abre el archivo para lectura
    archivo = fopen(nombreArchivo, "r");

    // Verifica si se pudo abrir el archivo
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo %s.\n", nombreArchivo);
        return 0;
    }

    char palabra[10];  // Variable para leer la primera palabra

    // Lee la primera palabra
    if (fscanf(archivo, "%s", palabra) != 1) {
        printf("Error al leer la primera palabra.\n");
        fclose(archivo);
        return 0;
    }

    // Verifica si la primera palabra es SIMPLE o CAPTURA
    if (strcmp(palabra, "SIMPLE") == 0) {
        *tipo_jugada = 0;  // Si es SIMPLE, asigna 0 a tipo_jugada
    } else if (strcmp(palabra, "CAPTURA") == 0) {
        *tipo_jugada = 1;  // Si es CAPTURA, asigna 1 a tipo_jugada
    } else {
        printf("Valor desconocido en la primera palabra.\n");
        fclose(archivo);
        return 0;
    }

    // Lee la segunda línea
    if (fscanf(archivo, "La coordenada del dado es %c,%d\n", caracter, numero) != 2) {
        printf("Error al leer la segunda línea.\n");
        fclose(archivo);
        return 0;
    }

    // Verifica si el número y el carácter están en rango
    if ((*numero < 1 || *numero > 5) || (*caracter < 'A' || *caracter > 'E')) {
        printf("Número o carácter fuera de rango.\n");
        fclose(archivo);
        return 0;
    }

    // Cierra el archivo
    fclose(archivo);

    return 1;
}

