#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include "constantes.h"
#include "tablero.h"
#include "usuario.h"
#include "computadora.h"
#include "TP_FINAL_LP1.h"

extern int tablero[TAM_TABLERO][TAM_TABLERO];
extern int matrizcapturas[4][3];
extern int posiblescapturas;
extern int tableroposic[TAM_TABLERO][TAM_TABLERO];


int modo = 0;
int color = 0;
int inicia = 0;
gboolean rojo_presionado = FALSE;
gboolean azul_presionado = FALSE;
gboolean aleatorio_presionado = FALSE;
gboolean J1_presionado = FALSE;
gboolean J2_presionado = FALSE;
gboolean JA_presionado = FALSE;

GtkBuilder *builder;
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *window3;
GtkWidget *window4;
GtkWidget *window5;
GtkWidget *window6;
GtkWidget *window7;
GtkWidget *helpWindow;
GtkWidget *aboutWindow;

GtkWidget *button_start;
GtkWidget *rojo_button;
GtkWidget *azul_button;
GtkWidget *aleatorio_button;
GtkWidget *buttonJ1;
GtkWidget *buttonJ2;
GtkWidget *buttonJA;

GtkWidget *image_widget;


// Prototipos de funciones de callback
// menú
void on_menu_help_activate(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_about_activate(GtkMenuItem *menuitem, gpointer user_data);
void on_about_close_clicked(GtkButton *button, gpointer user_data);
void on_help_close_clicked(GtkButton *button, gpointer user_data);
gboolean on_help_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data);
gboolean on_about_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data);

// quits
void on_menu_file_quit_activate1(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_file_quit_activate2(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_file_quit_activate3(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_file_quit_activate4(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_file_quit_activate5(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_file_quit_activate6(GtkMenuItem *menuitem, gpointer user_data);


void on_button_play_clicked(GtkButton *button, gpointer user_data);
void on_button_cvsc_clicked(GtkButton *button, gpointer user_data);
void on_button_hvsc_clicked(GtkButton *button, gpointer user_data);
void on_button_return_clicked(GtkButton *button, gpointer user_data);
void on_button_start_clicked(GtkButton *button, gpointer user_data);
void update_start_button_sensitive();
void actualizar_apariencia_botones();
void actualizar_apariencia_botones_inicia();
void on_button_rojo_clicked(GtkButton *button, gpointer user_data);
void on_button_azul_clicked(GtkButton *button, gpointer user_data);
void on_button_aleatorio_clicked(GtkButton *button, gpointer user_data);
void on_button_j1_clicked(GtkButton *button, gpointer user_data);
void on_button_j2_clicked(GtkButton *button, gpointer user_data);
void on_button_ja_clicked(GtkButton *button, gpointer user_data);
void connect_tablero_buttons();
void cambiar_fondo_predeterminado();
void cambiar_fondo_futbol();
void cambiar_fondo_swiftie();
void cambiar_fondo_estrellas();
void cambiar_fondo_paris();
void cambiar_imagen_window4(const gchar *imagen_path);
void on_button_tablero_clicked(GtkWidget *button, gpointer user_data);
void obtenerCoordenadasDesdeBoton(GtkWidget *button, int *coordenadas);
void obtenerColor();
void obtenerInicia();
void on_button_tableroj2start_clicked();
void funcion_que_muestra_y_destruye() ;
void show_and_destroy_window(GtkWidget *window);
gboolean destroy_window(GtkWidget *window);

void actualizarBotonA5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonA4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonA3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonA2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonA1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE1(int tablero[5][5], int tableroposic[5][5], int color);





// Función para ocultar y destruir un widget si es válido
void hide_and_destroy_if_valid(GtkWidget *widget) {
    if (GTK_IS_WIDGET(widget) && gtk_widget_get_visible(widget)) {
        gtk_widget_destroy(widget);
    }
}

int main(int argc, char *argv[]) {

	// Inicializar GTK y construcción del Glade
    GError *error = NULL;
    gtk_init(&argc, &argv);
    int ret;
    builder = gtk_builder_new();
    ret = gtk_builder_add_from_file(builder, "cphalopod.glade", &error);
    if (ret == 0) {
        g_print("Error en la función gtk_builder_add_from_file:\n%s", error->message);
        g_clear_error(&error);
        return 1;
    }
    gtk_builder_connect_signals(builder, NULL);





    // Obtener los punteros a las ventanas y otros widgets
    window1 = GTK_WIDGET(gtk_builder_get_object(builder, "window1"));
    gtk_window_set_position(GTK_WINDOW(window1), GTK_WIN_POS_CENTER);
    window2 = GTK_WIDGET(gtk_builder_get_object(builder, "window2"));
    gtk_window_set_position(GTK_WINDOW(window2), GTK_WIN_POS_CENTER);
    window3 = GTK_WIDGET(gtk_builder_get_object(builder, "window3"));
    gtk_window_set_position(GTK_WINDOW(window3), GTK_WIN_POS_CENTER);
    window4 = GTK_WIDGET(gtk_builder_get_object(builder, "window4"));
    gtk_window_set_position(GTK_WINDOW(window4), GTK_WIN_POS_CENTER);
    window5 = GTK_WIDGET(gtk_builder_get_object(builder, "window5"));
    gtk_window_set_position(GTK_WINDOW(window5), GTK_WIN_POS_CENTER);
    window6 = GTK_WIDGET(gtk_builder_get_object(builder, "window6"));
    gtk_window_set_position(GTK_WINDOW(window6), GTK_WIN_POS_CENTER);
    window7 = GTK_WIDGET(gtk_builder_get_object(builder, "window7"));
    gtk_window_set_position(GTK_WINDOW(window7), GTK_WIN_POS_CENTER);
    helpWindow = GTK_WIDGET(gtk_builder_get_object(builder, "HelpWindow"));
    gtk_window_set_position(GTK_WINDOW(helpWindow), GTK_WIN_POS_CENTER);
    aboutWindow = GTK_WIDGET(gtk_builder_get_object(builder, "AboutWindow"));
    gtk_window_set_position(GTK_WINDOW(aboutWindow), GTK_WIN_POS_CENTER);
    rojo_button = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonRojoW3"));
    azul_button = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonAzulW3"));
    aleatorio_button = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonAleatorioColorW3"));
    buttonJ1 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonJ1"));
    buttonJ2 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonJ2"));
    buttonJA = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonJA"));





    // GTK dialog
    GtkWidget *button_cerrar_about = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonCerrarHelp"));
    if (button_cerrar_about != NULL) {
        g_signal_connect(G_OBJECT(button_cerrar_about), "clicked", G_CALLBACK(on_about_close_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Cerrar\" en AboutWindow.\n");
        return 1;
    }

    GtkWidget *button_cerrar_help = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonCerrarReglas1"));
    if (button_cerrar_help != NULL) {
        g_signal_connect(G_OBJECT(button_cerrar_help), "clicked", G_CALLBACK(on_help_close_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Cerrar\" en HelpWindow.\n");
        return 1;
    }

    g_signal_connect(G_OBJECT(aboutWindow), "delete-event", G_CALLBACK(on_about_window_delete_event), NULL);
    g_signal_connect(G_OBJECT(helpWindow), "delete-event", G_CALLBACK(on_help_window_delete_event), NULL);





    /* WINDOW1 */
    // Barra de Menú

    // quit
    GtkWidget *file_quit_menu_item1 = GTK_WIDGET(gtk_builder_get_object(builder, "quit1"));
    if (file_quit_menu_item1 == NULL) {
        g_print("Error: No se pudo obtener el elemento del menú \"Quit\" en window1.\n");
        return 1;
    }
    g_signal_connect(G_OBJECT(file_quit_menu_item1), "activate", G_CALLBACK(on_menu_file_quit_activate1), NULL);


    // about
    GtkWidget *file_about_menu_item1 = GTK_WIDGET(gtk_builder_get_object(builder, "abou1"));
    if (file_about_menu_item1 != NULL) {
    	g_signal_connect(G_OBJECT(file_about_menu_item1), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
    	g_print("Error: No se pudo obtener el botón \"About del menú file\".\n");
    return 1;
    }

    GtkWidget *about_about_menu_item1 = GTK_WIDGET(gtk_builder_get_object(builder, "abo1"));
    if (about_about_menu_item1 != NULL) {
        g_signal_connect(G_OBJECT(about_about_menu_item1), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú About\".\n");
    return 1;
    }


    // help
    GtkWidget *file_help_menu_item1 = GTK_WIDGET(gtk_builder_get_object(builder, "hel1"));
    if (file_help_menu_item1 != NULL) {
    	g_signal_connect(G_OBJECT(file_help_menu_item1), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
    	g_print("Error: No se pudo obtener el botón \"Help del menú file\".\n");
    return 1;
    }

    GtkWidget *help_help_menu_item1 = GTK_WIDGET(gtk_builder_get_object(builder, "he1"));
    if (help_help_menu_item1 != NULL) {
        g_signal_connect(G_OBJECT(help_help_menu_item1), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú Help\".\n");
    return 1;
    }


    // Botones

    // play
    GtkWidget *button_play = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonPlay"));
    if (button_play != NULL) {
        g_signal_connect(G_OBJECT(button_play), "clicked", G_CALLBACK(on_button_play_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtonPlay\".\n");
        return 1;
    }





    /* WINDOW 2 */
    // Barra de Menú

    // quit
    GtkWidget *file_quit_menu_item2 = GTK_WIDGET(gtk_builder_get_object(builder, "quit2"));
    if (file_quit_menu_item2 == NULL) {
    	g_print("Error: No se pudo obtener el elemento del menú \"Quit\" en window2.\n");
        return 1;
    }
    g_signal_connect(G_OBJECT(file_quit_menu_item2), "activate", G_CALLBACK(on_menu_file_quit_activate2), NULL);


    // about
    GtkWidget *file_about_menu_item2 = GTK_WIDGET(gtk_builder_get_object(builder, "abou2"));
    if (file_about_menu_item2 != NULL) {
        g_signal_connect(G_OBJECT(file_about_menu_item2), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú file\".\n");
    return 1;
    }

    GtkWidget *about_about_menu_item2 = GTK_WIDGET(gtk_builder_get_object(builder, "abo2"));
    if (about_about_menu_item2 != NULL) {
    	g_signal_connect(G_OBJECT(about_about_menu_item2), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú About\".\n");
    return 1;
    }


    // help
    GtkWidget *file_help_menu_item2 = GTK_WIDGET(gtk_builder_get_object(builder, "hel2"));
    if (file_help_menu_item2 != NULL) {
    	g_signal_connect(G_OBJECT(file_help_menu_item2), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú file\".\n");
    return 1;
    }

    GtkWidget *help_help_menu_item2 = GTK_WIDGET(gtk_builder_get_object(builder, "he2"));
    if (help_help_menu_item2 != NULL) {
    	g_signal_connect(G_OBJECT(help_help_menu_item2), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú Help\".\n");
    return 1;
    }


    // Botones

    // cvsc
    GtkWidget *button_cvsc = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonCvsC"));
    if (button_cvsc != NULL) {
        g_signal_connect(G_OBJECT(button_cvsc), "clicked", G_CALLBACK(on_button_cvsc_clicked), button_start);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtonCvsC\".\n");
        return 1;
    }


    // hvsc
    GtkWidget *button_hvsc = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonHvsC"));
    if (button_hvsc != NULL) {
        g_signal_connect(G_OBJECT(button_hvsc), "clicked", G_CALLBACK(on_button_hvsc_clicked), button_start);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtonCvsC\".\n");
        return 1;
    }





    /* WINDOW 3 */
    // Barra de Menú

    // quit
    GtkWidget *file_quit_menu_item3 = GTK_WIDGET(gtk_builder_get_object(builder, "quit3"));
    if (file_quit_menu_item3 == NULL) {
    	g_print("Error: No se pudo obtener el elemento del menú \"Quit\" en window3.\n");
        return 1;
    }
    g_signal_connect(G_OBJECT(file_quit_menu_item3), "activate", G_CALLBACK(on_menu_file_quit_activate3), NULL);


    // about
    GtkWidget *file_about_menu_item3 = GTK_WIDGET(gtk_builder_get_object(builder, "abou3"));
    if (file_about_menu_item3 != NULL) {
        g_signal_connect(G_OBJECT(file_about_menu_item3), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú file\".\n");
    return 1;
    }

    GtkWidget *about_about_menu_item3 = GTK_WIDGET(gtk_builder_get_object(builder, "abo3"));
    if (about_about_menu_item3 != NULL) {
    	g_signal_connect(G_OBJECT(about_about_menu_item3), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú About\".\n");
    return 1;
    }


    // help
    GtkWidget *file_help_menu_item3 = GTK_WIDGET(gtk_builder_get_object(builder, "hel3"));
    if (file_help_menu_item3 != NULL) {
    	g_signal_connect(G_OBJECT(file_help_menu_item3), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú file\".\n");
    return 1;
    }

    GtkWidget *help_help_menu_item3 = GTK_WIDGET(gtk_builder_get_object(builder, "he3"));
    if (help_help_menu_item3 != NULL) {
    	g_signal_connect(G_OBJECT(help_help_menu_item3), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú Help\".\n");
    return 1;
    }


    // Botones

    // return
    GtkWidget *button_return = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonVolverW3"));
    if (button_return != NULL) {
        g_signal_connect(G_OBJECT(button_return), "clicked", G_CALLBACK(on_button_return_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtonCvsC\".\n");
        return 1;
    }


    // start
    GtkWidget *button_start = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonStartW3"));
    if (button_start != NULL) {
        g_signal_connect(G_OBJECT(button_start), "clicked", G_CALLBACK(on_button_start_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Start\".\n");
        return 1;
    }


    // elegir color

    if (rojo_button != NULL) {
        g_signal_connect(G_OBJECT(rojo_button), "clicked", G_CALLBACK(on_button_rojo_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Rojo\".\n");
        return 1;
    }

    if (azul_button != NULL) {
    	g_signal_connect(G_OBJECT(azul_button), "clicked", G_CALLBACK(on_button_azul_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Azul\".\n");
        return 1;
    }

    if (aleatorio_button != NULL) {
        g_signal_connect(G_OBJECT(aleatorio_button), "clicked", G_CALLBACK(on_button_aleatorio_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Aleatorio\".\n");
        return 1;
    }

    // elegir jugador

    if (buttonJ1 != NULL) {
        g_signal_connect(G_OBJECT(buttonJ1), "clicked", G_CALLBACK(on_button_j1_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtomJ1\".\n");
        return 1;
    }

    if (buttonJ2 != NULL) {
        g_signal_connect(G_OBJECT(buttonJ2), "clicked", G_CALLBACK(on_button_j2_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtomJ2\".\n");
        return 1;
    }

    if (buttonJA != NULL) {
        g_signal_connect(G_OBJECT(buttonJA), "clicked", G_CALLBACK(on_button_ja_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtomJA\".\n");
        return 1;
    }





    /* WINDOW 4 */
    image_widget = GTK_WIDGET(gtk_builder_get_object(builder, "ImagenWindow5"));
    connect_tablero_buttons();

    // Barra de Menú

    // quit
    GtkWidget *file_quit_menu_item4 = GTK_WIDGET(gtk_builder_get_object(builder, "quit4"));
    if (file_quit_menu_item4 == NULL) {
    	g_print("Error: No se pudo obtener el elemento del menú \"Quit\" en window4.\n");
        return 1;
    }
    g_signal_connect(G_OBJECT(file_quit_menu_item4), "activate", G_CALLBACK(on_menu_file_quit_activate4), NULL);


    // about
    GtkWidget *file_about_menu_item4 = GTK_WIDGET(gtk_builder_get_object(builder, "abou4"));
    if (file_about_menu_item4 != NULL) {
        g_signal_connect(G_OBJECT(file_about_menu_item4), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú file\".\n");
    return 1;
    }

    GtkWidget *about_about_menu_item4 = GTK_WIDGET(gtk_builder_get_object(builder, "abo4"));
    if (about_about_menu_item4 != NULL) {
    	g_signal_connect(G_OBJECT(about_about_menu_item4), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú About\".\n");
    return 1;
    }


    // help
    GtkWidget *file_help_menu_item4 = GTK_WIDGET(gtk_builder_get_object(builder, "hel4"));
    if (file_help_menu_item4 != NULL) {
    	g_signal_connect(G_OBJECT(file_help_menu_item4), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú file\".\n");
    return 1;
    }

    GtkWidget *help_help_menu_item4 = GTK_WIDGET(gtk_builder_get_object(builder, "he4"));
    if (help_help_menu_item4 != NULL) {
    	g_signal_connect(G_OBJECT(help_help_menu_item4), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú Help\".\n");
    return 1;
    }

		// Conecta la señal de clic de cada botón a la función on_button_clicked
				for (char letra = 'A'; letra <= 'E'; letra++) {
					for (int i = 1; i <= 5; i++) {

						gchar *button_name = g_strdup_printf("Button%c%d", letra, i);
						GtkWidget *button = GTK_WIDGET(gtk_builder_get_object(builder, button_name));

						g_signal_connect(button, "clicked", G_CALLBACK(on_button_tablero_clicked), NULL);
						g_free(button_name);
					}
				}




















    gtk_widget_show_all(window1);
    gtk_main();

    return 0;
}

/* FUNCIONES DE BARRA DE MENÚ */
void on_menu_help_activate(GtkMenuItem *menuitem, gpointer user_data) {
    gtk_widget_show_all(helpWindow);
}

void on_menu_about_activate(GtkMenuItem *menuitem, gpointer user_data) {
    gtk_widget_show_all(aboutWindow);
}


/* FUNCIONES DE WINDOW 1*/
void on_menu_file_quit_activate1(GtkMenuItem *menuitem, gpointer user_data) {
	hide_and_destroy_if_valid(window1);
	funcion_que_muestra_y_destruye();
}

void on_button_play_clicked(GtkButton *button, gpointer user_data) {
    hide_and_destroy_if_valid(window1);
    gtk_widget_show_all(window2);
}





/* FUNCIONES DE WINDOW 2 */
void on_menu_file_quit_activate2(GtkMenuItem *menuitem, gpointer user_data) {
	hide_and_destroy_if_valid(window2);
	funcion_que_muestra_y_destruye();
}

void on_button_cvsc_clicked(GtkButton *button, gpointer user_data) {
	GtkWidget *button_start = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonStartW3"));
	gtk_widget_hide(window2);
    gtk_widget_show_all(window3);
    gtk_widget_set_sensitive(button_start, FALSE);
    modo=1;
}

void on_button_hvsc_clicked(GtkButton *button, gpointer user_data) {
	GtkWidget *button_start = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonStartW3"));
	gtk_widget_hide(window2);
    gtk_widget_show_all(window3);
    gtk_widget_set_sensitive(button_start, FALSE);
    modo=2;
}





/* FUNCIONES DE WINDOW 3 */
void on_menu_file_quit_activate3(GtkMenuItem *menuitem, gpointer user_data) {
	hide_and_destroy_if_valid(window3);
	funcion_que_muestra_y_destruye();
}

void on_button_return_clicked(GtkButton *button, gpointer user_data) {
	gtk_widget_hide(window3);
    gtk_widget_show_all(window2);
}

void on_button_start_clicked(GtkButton *button, gpointer user_data) {
	gtk_widget_hide(window3);
    gtk_widget_show_all(window4);
    if (inicia==2)
    	on_button_tableroj2start_clicked();
}

void update_start_button_sensitive() {
    gboolean group1_presionado = rojo_presionado || azul_presionado || aleatorio_presionado;
    gboolean group2_presionado = J1_presionado || J2_presionado || JA_presionado;

    // Verifica si al menos uno de cada grupo está presionado
    gboolean any_button_presionado = group1_presionado && group2_presionado;

    // Obtén el botón "Start" desde el builder
    GtkWidget *button_start = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonStartW3"));

    // Actualiza la sensibilidad del botón "Start" según el estado de los demás botones
    gtk_widget_set_sensitive(button_start, any_button_presionado);
}


void actualizar_apariencia_botones() {
    // Restaurar la apariencia predeterminada de todos los botones y etiquetas
    gtk_button_set_relief(GTK_BUTTON(rojo_button), GTK_RELIEF_NONE);
    gtk_button_set_relief(GTK_BUTTON(azul_button), GTK_RELIEF_NONE);
    gtk_button_set_relief(GTK_BUTTON(aleatorio_button), GTK_RELIEF_NONE);

    if (rojo_presionado) {
        gtk_button_set_relief(GTK_BUTTON(rojo_button), GTK_RELIEF_NORMAL);
    }

    if (azul_presionado) {
        gtk_button_set_relief(GTK_BUTTON(azul_button), GTK_RELIEF_NORMAL);
    }

    if (aleatorio_presionado) {
        gtk_button_set_relief(GTK_BUTTON(aleatorio_button), GTK_RELIEF_NORMAL);
    }
}

void actualizar_apariencia_botones_inicia() {
    // Restaurar la apariencia predeterminada de todos los botones y etiquetas
    gtk_button_set_relief(GTK_BUTTON(buttonJ1), GTK_RELIEF_NONE);
    gtk_button_set_relief(GTK_BUTTON(buttonJ2), GTK_RELIEF_NONE);
    gtk_button_set_relief(GTK_BUTTON(buttonJA), GTK_RELIEF_NONE);

    if (J1_presionado) {
        gtk_button_set_relief(GTK_BUTTON(buttonJ1), GTK_RELIEF_NORMAL);
    }

    if (J2_presionado) {
        gtk_button_set_relief(GTK_BUTTON(buttonJ2), GTK_RELIEF_NORMAL);
    }

    if (JA_presionado) {
        gtk_button_set_relief(GTK_BUTTON(buttonJA), GTK_RELIEF_NORMAL);
    }
}

void on_button_rojo_clicked(GtkButton *button, gpointer user_data) {
	 rojo_presionado = TRUE;
	 azul_presionado = FALSE;
	 aleatorio_presionado = FALSE;
	 actualizar_apariencia_botones();
	 update_start_button_sensitive();
	 obtenerColor();
}

void on_button_azul_clicked(GtkButton *button, gpointer user_data) {
	 rojo_presionado = FALSE;
	 azul_presionado = TRUE;
	 aleatorio_presionado = FALSE;
	 actualizar_apariencia_botones();
	 update_start_button_sensitive();
	 obtenerColor();
}

void on_button_aleatorio_clicked(GtkButton *button, gpointer user_data) {
	 rojo_presionado = FALSE;
	 azul_presionado = FALSE;
	 aleatorio_presionado = TRUE;
	 actualizar_apariencia_botones();
	 update_start_button_sensitive();
	 obtenerColor();
}

void on_button_j1_clicked(GtkButton *button, gpointer user_data) {
	 J1_presionado = TRUE;
	 J2_presionado = FALSE;
	 JA_presionado = FALSE;
	 actualizar_apariencia_botones_inicia();
	 update_start_button_sensitive();
	 obtenerInicia();
}

void on_button_j2_clicked(GtkButton *button, gpointer user_data) {
	 J1_presionado = FALSE;
	 J2_presionado = TRUE;
	 JA_presionado = FALSE;
	 actualizar_apariencia_botones_inicia();
	 update_start_button_sensitive();
	 obtenerInicia();
}

void on_button_ja_clicked(GtkButton *button, gpointer user_data) {
	 J1_presionado = FALSE;
	 J2_presionado = FALSE;
	 JA_presionado = TRUE;
	 actualizar_apariencia_botones_inicia();
	 update_start_button_sensitive();
	 obtenerInicia();
}

void obtenerColor() {
    if (rojo_presionado) {
        color = 1;
    } else if (azul_presionado) {
        color = 2;
    } else if (aleatorio_presionado) {
        // Genera un número aleatorio entre 1 y 2
        color = (rand() % 2) + 1;
    }
}

void obtenerInicia() {
    if (J1_presionado) {
        inicia = 1;
    } else if (J2_presionado) {
        inicia = 2;
    } else if (JA_presionado) {
        // Genera un número aleatorio entre 1 y 2
        inicia = (rand() % 2) + 1;
    }
}





/* FUNCIONES DE WINDOW 4 */


void on_menu_file_quit_activate4(GtkMenuItem *menuitem, gpointer user_data) {
	hide_and_destroy_if_valid(window4);
	funcion_que_muestra_y_destruye();
}

/* Función para conectar los botones del menú "Tablero" a las funciones correspondientes */

void connect_tablero_buttons() {
    GtkWidget *tablero_predeterminado_button = GTK_WIDGET(gtk_builder_get_object(builder, "tableropredeterminado"));
    GtkWidget *tablero_futbol_button = GTK_WIDGET(gtk_builder_get_object(builder, "tablerofutbol"));
    GtkWidget *tablero_swiftie_button = GTK_WIDGET(gtk_builder_get_object(builder, "tableroswiftie"));
    GtkWidget *tablero_estrellas_button = GTK_WIDGET(gtk_builder_get_object(builder, "tableroestrellas"));
    GtkWidget *tablero_paris_button = GTK_WIDGET(gtk_builder_get_object(builder, "tableroparis"));

    g_signal_connect(G_OBJECT(tablero_predeterminado_button), "activate", G_CALLBACK(cambiar_fondo_predeterminado), NULL);
    g_signal_connect(G_OBJECT(tablero_futbol_button), "activate", G_CALLBACK(cambiar_fondo_futbol), NULL);
    g_signal_connect(G_OBJECT(tablero_swiftie_button), "activate", G_CALLBACK(cambiar_fondo_swiftie), NULL);
    g_signal_connect(G_OBJECT(tablero_estrellas_button), "activate", G_CALLBACK(cambiar_fondo_estrellas), NULL);
    g_signal_connect(G_OBJECT(tablero_paris_button), "activate", G_CALLBACK(cambiar_fondo_paris), NULL);
}

/* Funciones para cambiar el fondo de window4 según la opción de Tablero */

void cambiar_fondo_predeterminado() {
    cambiar_imagen_window4("1.png");
}

void cambiar_fondo_futbol() {
    cambiar_imagen_window4("2.png");
}

void cambiar_fondo_swiftie() {
    cambiar_imagen_window4("3.png");
}

void cambiar_fondo_estrellas() {
    cambiar_imagen_window4("4.png");
}

void cambiar_fondo_paris() {
    cambiar_imagen_window4("5.png");
}

void cambiar_imagen_window4(const gchar *imagen_path) {
    GtkWidget *image_widget = GTK_WIDGET(gtk_builder_get_object(builder, "ImagenWindow5"));
    if (image_widget != NULL) {
        GdkPixbuf *pixbuf = gdk_pixbuf_new_from_file(imagen_path, NULL);
        if (pixbuf != NULL) {
            gtk_image_set_from_pixbuf(GTK_IMAGE(image_widget), pixbuf);
            g_object_unref(pixbuf);
        } else {
            g_print("Error: No se pudo cargar la imagen: %s\n", imagen_path);
        }
    } else {
        g_print("Error: No se pudo obtener el widget de imagen en window4.\n");
    }
}

//Funciones para cambiar la imagen de los botones
const char *nombres_imagenes[] = {
    "inicial.png", "azul1.png", "azul2.png", "azul3.png", "azul4.png",
	"azul5.png", "azul6.png", "rojo1.png", "rojo2.png",
	"rojo3.png", "rojo4.png", "rojo5.png", "rojo6.png"
};



void obtenerCoordenadasDesdeBoton(GtkWidget *button, int *coordenadas) {
	// Obtener el nombre del botón clickeado
		 const gchar *button_name = gtk_widget_get_name(button);

		    // Imprimir el nombre del botón
		    g_print("Botón clickeado: %s\n", button_name);



    if (button_name== NULL || strncmp(button_name, "Button", 6) != 0 || button_name[6] < 'A' || button_name[6] > 'E' || button_name[7] < '1' || button_name[7] > '5') {
        fprintf(stderr, "Nombre de botón no válido.\n");
        exit(EXIT_FAILURE);
    }

    coordenadas[1] = (button_name[7] - '0');  // Fila (y)
    coordenadas[0] = button_name[6] - 'A' + 1;     // Columna (x)
}








void on_button_tablero_clicked(GtkWidget *button, gpointer user_data) {
	int coordenadas[2];
	obtenerCoordenadasDesdeBoton(button, coordenadas);




	principalgtk(coordenadas, color);
	actualizarBotonA5(tablero, tableroposic, color);
	actualizarBotonA4(tablero, tableroposic, color);
	actualizarBotonA3(tablero, tableroposic, color);
	actualizarBotonA2(tablero, tableroposic, color);
	actualizarBotonA1(tablero, tableroposic, color);
	actualizarBotonB5(tablero, tableroposic, color);
	actualizarBotonB4(tablero, tableroposic, color);
	actualizarBotonB3(tablero, tableroposic, color);
	actualizarBotonB2(tablero, tableroposic, color);
	actualizarBotonB1(tablero, tableroposic, color);
	actualizarBotonC5(tablero, tableroposic, color);
	actualizarBotonC4(tablero, tableroposic, color);
	actualizarBotonC3(tablero, tableroposic, color);
	actualizarBotonC2(tablero, tableroposic, color);
	actualizarBotonC1(tablero, tableroposic, color);
	actualizarBotonD5(tablero, tableroposic, color);
	actualizarBotonD4(tablero, tableroposic, color);
	actualizarBotonD3(tablero, tableroposic, color);
	actualizarBotonD2(tablero, tableroposic, color);
	actualizarBotonD1(tablero, tableroposic, color);
	actualizarBotonE5(tablero, tableroposic, color);
	actualizarBotonE4(tablero, tableroposic, color);
	actualizarBotonE3(tablero, tableroposic, color);
	actualizarBotonE2(tablero, tableroposic, color);
	actualizarBotonE1(tablero, tableroposic, color);
}

void on_button_tableroj2start_clicked() {
	principalgtk1(color);
	actualizarBotonA5(tablero, tableroposic, color);
	actualizarBotonA4(tablero, tableroposic, color);
	actualizarBotonA3(tablero, tableroposic, color);
	actualizarBotonA2(tablero, tableroposic, color);
	actualizarBotonA1(tablero, tableroposic, color);
	actualizarBotonB5(tablero, tableroposic, color);
	actualizarBotonB4(tablero, tableroposic, color);
	actualizarBotonB3(tablero, tableroposic, color);
	actualizarBotonB2(tablero, tableroposic, color);
	actualizarBotonB1(tablero, tableroposic, color);
	actualizarBotonC5(tablero, tableroposic, color);
	actualizarBotonC4(tablero, tableroposic, color);
	actualizarBotonC3(tablero, tableroposic, color);
	actualizarBotonC2(tablero, tableroposic, color);
	actualizarBotonC1(tablero, tableroposic, color);
	actualizarBotonD5(tablero, tableroposic, color);
	actualizarBotonD4(tablero, tableroposic, color);
	actualizarBotonD3(tablero, tableroposic, color);
	actualizarBotonD2(tablero, tableroposic, color);
	actualizarBotonD1(tablero, tableroposic, color);
	actualizarBotonE5(tablero, tableroposic, color);
	actualizarBotonE4(tablero, tableroposic, color);
	actualizarBotonE3(tablero, tableroposic, color);
	actualizarBotonE2(tablero, tableroposic, color);
	actualizarBotonE1(tablero, tableroposic, color);
}




/* FUNCIONES DE WINDOW 5 */
void on_menu_file_quit_activate5(GtkMenuItem *menuitem, gpointer user_data) {
	hide_and_destroy_if_valid(window5);
	funcion_que_muestra_y_destruye();
}





/* FUNCIONES DE WINDOW 6 */
void on_menu_file_quit_activate6(GtkMenuItem *menuitem, gpointer user_data) {
	hide_and_destroy_if_valid(window6);
	funcion_que_muestra_y_destruye();
}





/* FUNCIONES DE WINDOW 7 */
// Función para destruir la ventana
gboolean destroy_window(GtkWidget *window) {
    gtk_widget_destroy(window);
    return G_SOURCE_REMOVE;  // Elimina el evento después de ejecutarse
}

// Función que muestra la ventana y programa su destrucción después de cierto tiempo
void show_and_destroy_window(GtkWidget *window) {
    // Muestra la ventana
    gtk_widget_show_all(window);

    // Programa la destrucción después de 3000 milisegundos (3 segundos)
    g_timeout_add(1500, (GSourceFunc)destroy_window, window);
    g_timeout_add(1501, (GSourceFunc)gtk_main_quit, NULL);
}

// Ejemplo de cómo llamar a show_and_destroy_window desde otra función
void funcion_que_muestra_y_destruye() {
    // Obtén la ventana, por ejemplo, window7
    GtkWidget *window7 = GTK_WIDGET(gtk_builder_get_object(builder, "window7"));

    // Llama a la función que muestra la ventana y programa su destrucción
    show_and_destroy_window(window7);
}





/* FUNCIONES DE BARRA DE MENÚ */
void on_about_close_clicked(GtkButton *button, gpointer user_data) {
	gtk_widget_hide(aboutWindow);
}

void on_help_close_clicked(GtkButton *button, gpointer user_data) {
	gtk_widget_hide(helpWindow);
}

gboolean on_about_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data) {
    gtk_widget_hide(widget);  // Oculta la ventana About en lugar de destruirla
    return TRUE;  // Impide el manejo predeterminado del evento (evita que la ventana se destruya)
}

gboolean on_help_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data) {
    gtk_widget_hide(widget);  // Oculta la ventana Help en lugar de destruirla
    return TRUE;  // Impide el manejo predeterminado del evento (evita que la ventana se destruya)
}





/* FUNCIONES DE ACTUALIZAR BOTONES */
void actualizarBotonA5(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[0][0];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[0][0];

    // Obtener el widget de imagen
    GtkWidget *imagenA5 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenA5"));
    GtkWidget *botonA5 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonA5"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonA5, FALSE);
        else
        	gtk_widget_set_sensitive(botonA5, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenA5), rutaImagen);
}

void actualizarBotonA4(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[1][0];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[1][0];

    // Obtener el widget de imagen
    GtkWidget *imagenA4 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenA4"));
    GtkWidget *botonA4 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonA4"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
    	gtk_widget_set_sensitive(botonA4, FALSE);
    else
    	gtk_widget_set_sensitive(botonA4, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenA4), rutaImagen);
}

void actualizarBotonA3(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[2][0];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[2][0];

    // Obtener el widget de imagen
    GtkWidget *imagenA3 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenA3"));
    GtkWidget *botonA3 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonA3"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonA3, FALSE);
        else
        	gtk_widget_set_sensitive(botonA3, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenA3), rutaImagen);
}

void actualizarBotonA2(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[3][0];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[3][0];

    // Obtener el widget de imagen
    GtkWidget *imagenA2 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenA2"));
    GtkWidget *botonA2 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonA2"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonA2, FALSE);
        else
        	gtk_widget_set_sensitive(botonA2, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenA2), rutaImagen);
}

void actualizarBotonA1(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[4][0];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[4][0];

    // Obtener el widget de imagen
    GtkWidget *imagenA1 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenA1"));
    GtkWidget *botonA1 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonA1"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonA1, FALSE);
        else
        	gtk_widget_set_sensitive(botonA1, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenA1), rutaImagen);
}

void actualizarBotonB5(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[0][1];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[0][1];

    // Obtener el widget de imagen
    GtkWidget *imagenB5 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenB5"));
    GtkWidget *botonB5 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonB5"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonB5, FALSE);
        else
        	gtk_widget_set_sensitive(botonB5, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenB5), rutaImagen);
}

void actualizarBotonB4(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[1][1];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[1][1];

    // Obtener el widget de imagen
    GtkWidget *imagenB4 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenB4"));
    GtkWidget *botonB4 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonB4"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonB4, FALSE);
        else
        	gtk_widget_set_sensitive(botonB4, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenB4), rutaImagen);
}

void actualizarBotonB3(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[2][1];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[2][1];

    // Obtener el widget de imagen
    GtkWidget *imagenB3 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenB3"));
    GtkWidget *botonB3 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonB3"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonB3, FALSE);
        else
        	gtk_widget_set_sensitive(botonB3, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenB3), rutaImagen);
}

void actualizarBotonB2(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[3][1];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[3][1];

    // Obtener el widget de imagen
    GtkWidget *imagenB2 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenB2"));
    GtkWidget *botonB2 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonB2"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonB2, FALSE);
        else
        	gtk_widget_set_sensitive(botonB2, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenB2), rutaImagen);
}

void actualizarBotonB1(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[4][1];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[4][1];

    // Obtener el widget de imagen
    GtkWidget *imagenB1 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenB1"));
    GtkWidget *botonB1 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonB1"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonB1, FALSE);
        else
        	gtk_widget_set_sensitive(botonB1, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenB1), rutaImagen);
}

void actualizarBotonC5(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[0][2];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[0][2];

    // Obtener el widget de imagen
    GtkWidget *imagenC5 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenC5"));
    GtkWidget *botonC5 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonC5"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonC5, FALSE);
        else
        	gtk_widget_set_sensitive(botonC5, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenC5), rutaImagen);
}

void actualizarBotonC4(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[1][2];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[1][2];

    // Obtener el widget de imagen
    GtkWidget *imagenC4 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenC4"));
    GtkWidget *botonC4 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonC4"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonC4, FALSE);
        else
        	gtk_widget_set_sensitive(botonC4, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenC4), rutaImagen);
}

void actualizarBotonC3(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[2][2];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[2][2];

    // Obtener el widget de imagen
    GtkWidget *imagenC3 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenC3"));
    GtkWidget *botonC3 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonC3"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";


    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonC3, FALSE);
        else
        	gtk_widget_set_sensitive(botonC3, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenC3), rutaImagen);
}

void actualizarBotonC2(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[3][2];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[3][2];

    // Obtener el widget de imagen
    GtkWidget *imagenC2 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenC2"));
    GtkWidget *botonC2 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonC2"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonC2, FALSE);
        else
        	gtk_widget_set_sensitive(botonC2, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenC2), rutaImagen);
}

void actualizarBotonC1(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[4][2];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[4][2];

    // Obtener el widget de imagen
    GtkWidget *imagenC1 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenC1"));
    GtkWidget *botonC1 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonC1"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonC1, FALSE);
        else
        	gtk_widget_set_sensitive(botonC1, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenC1), rutaImagen);
}

void actualizarBotonD5(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[0][3];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[0][3];

    // Obtener el widget de imagen
    GtkWidget *imagenD5 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenD5"));
    GtkWidget *botonD5 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonD5"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonD5, FALSE);
        else
        	gtk_widget_set_sensitive(botonD5, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenD5), rutaImagen);
}

void actualizarBotonD4(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[1][3];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[1][3];

    // Obtener el widget de imagen
    GtkWidget *imagenD4 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenD4"));
    GtkWidget *botonD4 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonD4"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonD4, FALSE);
        else
        	gtk_widget_set_sensitive(botonD4, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenD4), rutaImagen);
}

void actualizarBotonD3(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[2][3];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[2][3];

    // Obtener el widget de imagen
    GtkWidget *imagenD3 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenD3"));
    GtkWidget *botonD3 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonD3"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonD3, FALSE);
        else
        	gtk_widget_set_sensitive(botonD3, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenD3), rutaImagen);
}

void actualizarBotonD2(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[3][3];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[3][3];

    // Obtener el widget de imagen
    GtkWidget *imagenD2 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenD2"));
    GtkWidget *botonD2 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonD2"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonD2, FALSE);
        else
        	gtk_widget_set_sensitive(botonD2, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenD2), rutaImagen);
}

void actualizarBotonD1(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[4][3];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[4][3];

    // Obtener el widget de imagen
    GtkWidget *imagenD1 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenD1"));
    GtkWidget *botonD1 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonD1"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonD1, FALSE);
        else
        	gtk_widget_set_sensitive(botonD1, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenD1), rutaImagen);
}

void actualizarBotonE5(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[0][4];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[0][4];

    // Obtener el widget de imagen
    GtkWidget *imagenE5 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenE5"));
    GtkWidget *botonE5 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonE5"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonE5, FALSE);
        else
        	gtk_widget_set_sensitive(botonE5, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenE5), rutaImagen);
}

void actualizarBotonE4(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[1][4];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[1][4];

    // Obtener el widget de imagen
    GtkWidget *imagenE4 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenE4"));
    GtkWidget *botonE4 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonE4"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonE4, FALSE);
        else
        	gtk_widget_set_sensitive(botonE4, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenE4), rutaImagen);
}

void actualizarBotonE3(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[2][4];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[2][4];

    // Obtener el widget de imagen
    GtkWidget *imagenE3 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenE3"));
    GtkWidget *botonE3 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonE3"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonE3, FALSE);
        else
        	gtk_widget_set_sensitive(botonE3, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenE3), rutaImagen);
}

void actualizarBotonE2(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[3][4];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[3][4];

    // Obtener el widget de imagen
    GtkWidget *imagenE2 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenE2"));
    GtkWidget *botonE2 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonE2"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonE2, FALSE);
        else
        	gtk_widget_set_sensitive(botonE2, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenE2), rutaImagen);
}

void actualizarBotonE1(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[4][4];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[4][4];

    // Obtener el widget de imagen
    GtkWidget *imagenE1 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenE1"));
    GtkWidget *botonE1 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonE1"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonE1, FALSE);
        else
        	gtk_widget_set_sensitive(botonE1, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenE1), rutaImagen);
}
