/*
 * computadora.h
 *
 *  Created on: 21 oct. 2023
 *      Author: lp1-2023
 */

#ifndef COMPUTADORA_H_
#define COMPUTADORA_H_

int libreCompu (int coordX, int coordY);
int* pedirJugadaCompu (void);
void turnoCompu (int jugador, int color);
gboolean ejecutarTurnoCompu(gpointer data);

#endif /* COMPUTADORA_H_ */
