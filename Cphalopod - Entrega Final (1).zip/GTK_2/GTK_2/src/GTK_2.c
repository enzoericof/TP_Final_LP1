#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include "constantes.h"
#include "tablero.h"
#include "preparacion.h"
#include "usuario.h"
#include "computadora.h"
#include "TP_FINAL_LP1.h"
#include "GTK_2.h"

// variables globales
extern int tablero[TAM_TABLERO][TAM_TABLERO];
extern int matrizcapturas[4][3];
extern int posiblescapturas;
extern int tableroposic[TAM_TABLERO][TAM_TABLERO];
extern int flag;
//extern int cont;
extern int TIEMPO;
int ganador;
int estado = 0;
int modo = 0;
int color = 0;
int inicia = 0;
gboolean rojo_presionado = FALSE;
gboolean azul_presionado = FALSE;
gboolean aleatorio_presionado = FALSE;
gboolean J1_presionado = FALSE;
gboolean J2_presionado = FALSE;
gboolean JA_presionado = FALSE;
GtkWidget *boton_con_relieve; // Reemplaza con el tipo de dato adecuado
int sumaaux; // Reemplaza con el tipo de dato adecuado
int contaux; // Reemplaza con el tipo de dato adecuado
int coordenadas_con_relieve[5][2];
int botonaux[2];
int coordenadas[2];


// punteros
GtkBuilder *builder;
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *window3;
GtkWidget *window4;
GtkWidget *window5;
GtkWidget *window6;
GtkWidget *window7;
GtkWidget *helpWindow;
GtkWidget *aboutWindow;
GtkWidget *newwarning;
GtkWidget *mainwarning;


GtkWidget *button_start;
GtkWidget *rojo_button;
GtkWidget *azul_button;
GtkWidget *aleatorio_button;
GtkWidget *buttonJ1;
GtkWidget *buttonJ2;
GtkWidget *buttonJA;

GtkWidget *image_widget;
GtkLabel *labelTurnoJugador1;
GtkLabel *labelTurnoJugador2;
GtkLabel *LabelGanador;


// Prototipos de funciones de callback
void on_menu_help_activate(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_about_activate(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_stats_activate(GtkMenuItem *menuitem, gpointer user_data);
void on_about_close_clicked(GtkButton *button, gpointer user_data);
void on_help_close_clicked(GtkButton *button, gpointer user_data);
void on_window5_inicio_clicked(GtkButton *button, gpointer user_data);
void on_window5_stats_clicked(GtkButton *button, gpointer user_data);
gboolean on_window5_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data);
gboolean on_window6_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data);
gboolean on_help_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data);
gboolean on_about_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data);
gboolean on_new_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data);
gboolean on_home_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data);
void on_menu_file_quit_activate1(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_file_quit_activate2(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_file_quit_activate3(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_file_quit_activate4(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_file_quit_activate5(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_file_quit_activate6(GtkMenuItem *menuitem, gpointer user_data);
void on_button_play_clicked(GtkButton *button, gpointer user_data);
void ocultar_elementos(GtkLabel *label, GtkEntry *entry, gpointer data);
void mostrar_elementos(GtkLabel *label, GtkEntry *entry, gpointer data);
void cambiar_label_nombre(GtkLabel *label1, GtkLabel *label2, GtkLabel *labeljugador1, GtkLabel *labeljugador2, GtkEntry *entry1,  GtkEntry *entry2, gpointer data);
void on_button_cvsc_clicked(GtkButton *button, gpointer user_data);
void on_button_hvsc_clicked(GtkButton *button, gpointer user_data);
void on_button_return_clicked(GtkButton *button, gpointer user_data);
void on_button_returnw6_clicked(GtkButton *button, gpointer user_data);
void button_start_info();
void show_custom_dialog(const gchar *format, ...);
void on_button_start_clicked(GtkButton *button, gpointer user_data);
void update_start_button_sensitive();
void actualizar_apariencia_botones();
void actualizar_apariencia_botones_inicia();
void on_button_rojo_clicked(GtkButton *button, gpointer user_data);
void on_button_azul_clicked(GtkButton *button, gpointer user_data);
void on_button_aleatorio_clicked(GtkButton *button, gpointer user_data);
void on_button_j1_clicked(GtkButton *button, gpointer user_data);
void on_button_j2_clicked(GtkButton *button, gpointer user_data);
void on_button_ja_clicked(GtkButton *button, gpointer user_data);
void connect_tablero_buttons();
void cambiar_fondo_predeterminado();
void cambiar_fondo_futbol();
void cambiar_fondo_swiftie();
void cambiar_fondo_estrellas();
void cambiar_fondo_atardecer();
void cambiar_imagen_window4(const gchar *imagen_path);
void on_button_tablero_clicked(GtkWidget *button, gpointer user_data);
void deshabilitar_botones_tablero(GtkBuilder *builder);
void activar_botones(int matrizcapturas[4][3]);
void obtenerCoordenadasDesdeBoton(GtkWidget *button, int *coordenadas);
void obtenerColor();
void obtenerInicia();
void on_button_tableroj2start_clicked();
void funcion_que_muestra_y_destruye() ;
void show_and_destroy_window(GtkWidget *window);
gboolean destroy_window(GtkWidget *window);
void hide_and_destroy_if_valid(GtkWidget *widget);
void ajustar_sensibilidad_button_captura(GtkWidget *button);
void on_button_captura_clicked(GtkButton *button, gpointer user_data);
void obtener_coordenadas_con_relieve();
void quitarRelieveBotones(GtkBuilder *builder);
void cambiar_label_turno(GtkLabel *labelTurno1, GtkLabel *labelTurno2, gpointer data);
void label_turno(int num);
void on_menu_file_new_activate(GtkMenuItem *menuitem, gpointer user_data);
void on_menu_file_home_activate(GtkMenuItem *menuitem, gpointer user_data);
void on_aceptar_new_clicked();
void on_cancelar_new_clicked();
void on_aceptar_home_clicked();
void on_cancelar_home_clicked();
void cambiar_label_ganador(GtkLabel *ganador, gpointer data);
gboolean evaluar_flag(gpointer user_data);


void actualizarBotonA5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonA4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonA3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonA2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonA1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotones(int tablero[5][5], int tableroposic[5][5], int color);
gboolean ejecutarActualizaciones(gpointer data);








int main(int argc, char *argv[]) {

	// Inicializar GTK y construcción del Glade
    GError *error = NULL;
    gtk_init(&argc, &argv);
    int ret;
    builder = gtk_builder_new();
    ret = gtk_builder_add_from_file(builder, "cphalopod.glade", &error);
    if (ret == 0) {
        g_print("Error en la función gtk_builder_add_from_file:\n%s", error->message);
        g_clear_error(&error);
        return 1;
    }
    gtk_builder_connect_signals(builder, NULL);





    // Obtener los punteros a las ventanas y otros widgets
    window1 = GTK_WIDGET(gtk_builder_get_object(builder, "window1"));
    gtk_window_set_position(GTK_WINDOW(window1), GTK_WIN_POS_CENTER);
    window2 = GTK_WIDGET(gtk_builder_get_object(builder, "window2"));
    gtk_window_set_position(GTK_WINDOW(window2), GTK_WIN_POS_CENTER);
    window3 = GTK_WIDGET(gtk_builder_get_object(builder, "window3"));
    gtk_window_set_position(GTK_WINDOW(window3), GTK_WIN_POS_CENTER);
    window4 = GTK_WIDGET(gtk_builder_get_object(builder, "window4"));
    gtk_window_set_position(GTK_WINDOW(window4), GTK_WIN_POS_CENTER);
    window6 = GTK_WIDGET(gtk_builder_get_object(builder, "window6"));
    gtk_window_set_position(GTK_WINDOW(window6), GTK_WIN_POS_CENTER);
    window7 = GTK_WIDGET(gtk_builder_get_object(builder, "window7"));
    gtk_window_set_position(GTK_WINDOW(window7), GTK_WIN_POS_CENTER);
    helpWindow = GTK_WIDGET(gtk_builder_get_object(builder, "HelpWindow"));
    gtk_window_set_position(GTK_WINDOW(helpWindow), GTK_WIN_POS_CENTER);
    aboutWindow = GTK_WIDGET(gtk_builder_get_object(builder, "AboutWindow"));
    gtk_window_set_position(GTK_WINDOW(aboutWindow), GTK_WIN_POS_CENTER);
    window5 = GTK_WIDGET(gtk_builder_get_object(builder, "window5"));
    gtk_window_set_position(GTK_WINDOW(window5), GTK_WIN_POS_CENTER);
    rojo_button = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonRojoW3"));
    azul_button = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonAzulW3"));
    aleatorio_button = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonAleatorioColorW3"));
    buttonJ1 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonJ1"));
    buttonJ2 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonJ2"));
    buttonJA = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonJA"));
    labelTurnoJugador1 = GTK_LABEL(gtk_builder_get_object(builder, "LabelJ1"));
    labelTurnoJugador2 = GTK_LABEL(gtk_builder_get_object(builder, "LabelJ2"));
    LabelGanador = GTK_LABEL(gtk_builder_get_object(builder, "LabelGanador"));
    newwarning = GTK_WIDGET(gtk_builder_get_object(builder, "NuevaPartidaWindow"));
    gtk_window_set_position(GTK_WINDOW(newwarning), GTK_WIN_POS_CENTER);
    mainwarning = GTK_WIDGET(gtk_builder_get_object(builder, "IralnicioW1"));
    gtk_window_set_position(GTK_WINDOW(mainwarning), GTK_WIN_POS_CENTER);





    // GTK dialog
    GtkWidget *button_cerrar_about = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonCerrarHelp"));
    if (button_cerrar_about != NULL) {
        g_signal_connect(G_OBJECT(button_cerrar_about), "clicked", G_CALLBACK(on_about_close_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Cerrar\" en AboutWindow.\n");
        return 1;
    }

    GtkWidget *button_inicio_window5 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonInicioW5"));
        if (button_inicio_window5 != NULL) {
            g_signal_connect(G_OBJECT(button_inicio_window5), "clicked", G_CALLBACK(on_window5_inicio_clicked), NULL);
        } else {
            g_print("Error: No se pudo obtener el botón \"Inicio\" en W5\n");
            return 1;
        }

    GtkWidget *button_stats_window5 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonStatsW5"));
    if (button_stats_window5 != NULL) {
        g_signal_connect(G_OBJECT(button_stats_window5), "clicked", G_CALLBACK(on_window5_stats_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Estadísticas\" en W5.\n");
        return 1;
    }

    GtkWidget *button_aceptar_new = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonAceptar"));
    if (button_aceptar_new != NULL) {
        g_signal_connect(G_OBJECT(button_aceptar_new), "clicked", G_CALLBACK(on_aceptar_new_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"aceptar\" en new.\n");
        return 1;
    }

    GtkWidget *button_cancelar_new = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonCancelar"));
    if (button_cancelar_new != NULL) {
        g_signal_connect(G_OBJECT(button_cancelar_new), "clicked", G_CALLBACK(on_cancelar_new_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"cancelar\" en new.\n");
        return 1;
    }

    GtkWidget *button_aceptar_home = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonAceptar1"));
    if (button_aceptar_home != NULL) {
        g_signal_connect(G_OBJECT(button_aceptar_home), "clicked", G_CALLBACK(on_aceptar_home_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"aceptar\" en home.\n");
        return 1;
    }

    GtkWidget *button_cancelar_home = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonCancelar1"));
    if (button_cancelar_home != NULL) {
        g_signal_connect(G_OBJECT(button_cancelar_home), "clicked", G_CALLBACK(on_cancelar_home_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"cancelar\" en home.\n");
        return 1;
    }


    g_signal_connect(G_OBJECT(aboutWindow), "delete-event", G_CALLBACK(on_about_window_delete_event), NULL);
    g_signal_connect(G_OBJECT(helpWindow), "delete-event", G_CALLBACK(on_help_window_delete_event), NULL);
    g_signal_connect(G_OBJECT(window5), "delete-event", G_CALLBACK(on_window5_window_delete_event), NULL);
    g_signal_connect(G_OBJECT(window6), "delete-event", G_CALLBACK(on_window6_window_delete_event), NULL);
    g_signal_connect(G_OBJECT(newwarning), "delete-event", G_CALLBACK(on_window5_window_delete_event), NULL);
    g_signal_connect(G_OBJECT(mainwarning), "delete-event", G_CALLBACK(on_window6_window_delete_event), NULL);





    /* WINDOW1 */
    // Barra de Menú
    // quit
    GtkWidget *file_quit_menu_item1 = GTK_WIDGET(gtk_builder_get_object(builder, "quit1"));
    if (file_quit_menu_item1 == NULL) {
        g_print("Error: No se pudo obtener el elemento del menú \"Quit\" en window1.\n");
        return 1;
    }
    g_signal_connect(G_OBJECT(file_quit_menu_item1), "activate", G_CALLBACK(on_menu_file_quit_activate1), NULL);


    // about
    GtkWidget *file_about_menu_item1 = GTK_WIDGET(gtk_builder_get_object(builder, "abou1"));
    if (file_about_menu_item1 != NULL) {
    	g_signal_connect(G_OBJECT(file_about_menu_item1), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
    	g_print("Error: No se pudo obtener el botón \"About del menú file\".\n");
    return 1;
    }

    GtkWidget *about_about_menu_item1 = GTK_WIDGET(gtk_builder_get_object(builder, "abo1"));
    if (about_about_menu_item1 != NULL) {
        g_signal_connect(G_OBJECT(about_about_menu_item1), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú About\".\n");
    return 1;
    }


    // help
    GtkWidget *file_help_menu_item1 = GTK_WIDGET(gtk_builder_get_object(builder, "hel1"));
    if (file_help_menu_item1 != NULL) {
    	g_signal_connect(G_OBJECT(file_help_menu_item1), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
    	g_print("Error: No se pudo obtener el botón \"Help del menú file\".\n");
    return 1;
    }

    GtkWidget *help_help_menu_item1 = GTK_WIDGET(gtk_builder_get_object(builder, "he1"));
    if (help_help_menu_item1 != NULL) {
        g_signal_connect(G_OBJECT(help_help_menu_item1), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú Help\".\n");
    return 1;
    }


    // Estadísticas
    GtkWidget *estadisticas_menu_item1 = GTK_WIDGET(gtk_builder_get_object(builder, "estadisticas1"));
    if (estadisticas_menu_item1 != NULL) {
    	g_signal_connect(G_OBJECT(estadisticas_menu_item1), "activate", G_CALLBACK(on_menu_stats_activate), NULL);
    } else {
    	g_print("Error: No se pudo obtener el botón \"Estadísticas de W1\".\n");
    return 1;
    }



    // Botones
    // play
    GtkWidget *button_play = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonPlay"));
    if (button_play != NULL) {
        g_signal_connect(G_OBJECT(button_play), "clicked", G_CALLBACK(on_button_play_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtonPlay\".\n");
        return 1;
    }





    /* WINDOW 2 */
    // Barra de Menú
    // quit
    GtkWidget *file_quit_menu_item2 = GTK_WIDGET(gtk_builder_get_object(builder, "quit2"));
    if (file_quit_menu_item2 == NULL) {
    	g_print("Error: No se pudo obtener el elemento del menú \"Quit\" en window2.\n");
        return 1;
    }
    g_signal_connect(G_OBJECT(file_quit_menu_item2), "activate", G_CALLBACK(on_menu_file_quit_activate2), NULL);


    // about
    GtkWidget *file_about_menu_item2 = GTK_WIDGET(gtk_builder_get_object(builder, "abou2"));
    if (file_about_menu_item2 != NULL) {
        g_signal_connect(G_OBJECT(file_about_menu_item2), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú file\".\n");
    return 1;
    }

    GtkWidget *about_about_menu_item2 = GTK_WIDGET(gtk_builder_get_object(builder, "abo2"));
    if (about_about_menu_item2 != NULL) {
    	g_signal_connect(G_OBJECT(about_about_menu_item2), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú About\".\n");
    return 1;
    }


    // help
    GtkWidget *file_help_menu_item2 = GTK_WIDGET(gtk_builder_get_object(builder, "hel2"));
    if (file_help_menu_item2 != NULL) {
    	g_signal_connect(G_OBJECT(file_help_menu_item2), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú file\".\n");
    return 1;
    }

    GtkWidget *help_help_menu_item2 = GTK_WIDGET(gtk_builder_get_object(builder, "he2"));
    if (help_help_menu_item2 != NULL) {
    	g_signal_connect(G_OBJECT(help_help_menu_item2), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú Help\".\n");
    return 1;
    }


    // Estadisticas
    GtkWidget *estadisticas_menu_item2 = GTK_WIDGET(gtk_builder_get_object(builder, "estadisticas2"));
    if (estadisticas_menu_item2 != NULL) {
    	g_signal_connect(G_OBJECT(estadisticas_menu_item2), "activate", G_CALLBACK(on_menu_stats_activate), NULL);
    } else {
    	g_print("Error: No se pudo obtener el botón \"Estadísticas de W2\".\n");
    return 1;
    }



    // Botones
    // cvsc
    GtkWidget *button_cvsc = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonCvsC"));
    if (button_cvsc != NULL) {
        g_signal_connect(G_OBJECT(button_cvsc), "clicked", G_CALLBACK(on_button_cvsc_clicked), button_start);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtonCvsC\".\n");
        return 1;
    }

    // hvsc
    GtkWidget *button_hvsc = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonHvsC"));
    if (button_hvsc != NULL) {
        g_signal_connect(G_OBJECT(button_hvsc), "clicked", G_CALLBACK(on_button_hvsc_clicked), button_start);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtonCvsC\".\n");
        return 1;
    }





    /* WINDOW 3 */
    // Barra de Menú
    // quit
    GtkWidget *file_quit_menu_item3 = GTK_WIDGET(gtk_builder_get_object(builder, "quit3"));
    if (file_quit_menu_item3 == NULL) {
    	g_print("Error: No se pudo obtener el elemento del menú \"Quit\" en window3.\n");
        return 1;
    }
    g_signal_connect(G_OBJECT(file_quit_menu_item3), "activate", G_CALLBACK(on_menu_file_quit_activate3), NULL);


    // about
    GtkWidget *file_about_menu_item3 = GTK_WIDGET(gtk_builder_get_object(builder, "abou3"));
    if (file_about_menu_item3 != NULL) {
        g_signal_connect(G_OBJECT(file_about_menu_item3), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú file\".\n");
    return 1;
    }

    GtkWidget *about_about_menu_item3 = GTK_WIDGET(gtk_builder_get_object(builder, "abo3"));
    if (about_about_menu_item3 != NULL) {
    	g_signal_connect(G_OBJECT(about_about_menu_item3), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú About\".\n");
    return 1;
    }


    // help
    GtkWidget *file_help_menu_item3 = GTK_WIDGET(gtk_builder_get_object(builder, "hel3"));
    if (file_help_menu_item3 != NULL) {
    	g_signal_connect(G_OBJECT(file_help_menu_item3), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú file\".\n");
    return 1;
    }

    GtkWidget *help_help_menu_item3 = GTK_WIDGET(gtk_builder_get_object(builder, "he3"));
    if (help_help_menu_item3 != NULL) {
    	g_signal_connect(G_OBJECT(help_help_menu_item3), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú Help\".\n");
    return 1;
    }


    // Estadisticas
    GtkWidget *estadisticas_menu_item3 = GTK_WIDGET(gtk_builder_get_object(builder, "estadisticas3"));
    if (estadisticas_menu_item3 != NULL) {
    	g_signal_connect(G_OBJECT(estadisticas_menu_item3), "activate", G_CALLBACK(on_menu_stats_activate), NULL);
    } else {
    	g_print("Error: No se pudo obtener el botón \"Estadísticas de W3\".\n");
    return 1;
    }



    // Botones
    // return
    GtkWidget *button_return = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonVolverW3"));
    if (button_return != NULL) {
        g_signal_connect(G_OBJECT(button_return), "clicked", G_CALLBACK(on_button_return_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtonCvsC\".\n");
        return 1;
    }


    // start
    GtkWidget *button_start = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonStartW3"));
    if (button_start != NULL) {
        g_signal_connect(G_OBJECT(button_start), "clicked", G_CALLBACK(on_button_start_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Start\".\n");
        return 1;
    }


    // elegir color

    if (rojo_button != NULL) {
        g_signal_connect(G_OBJECT(rojo_button), "clicked", G_CALLBACK(on_button_rojo_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Rojo\".\n");
        return 1;
    }

    if (azul_button != NULL) {
    	g_signal_connect(G_OBJECT(azul_button), "clicked", G_CALLBACK(on_button_azul_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Azul\".\n");
        return 1;
    }

    if (aleatorio_button != NULL) {
        g_signal_connect(G_OBJECT(aleatorio_button), "clicked", G_CALLBACK(on_button_aleatorio_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Aleatorio\".\n");
        return 1;
    }

    // elegir jugador

    if (buttonJ1 != NULL) {
        g_signal_connect(G_OBJECT(buttonJ1), "clicked", G_CALLBACK(on_button_j1_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtomJ1\".\n");
        return 1;
    }

    if (buttonJ2 != NULL) {
        g_signal_connect(G_OBJECT(buttonJ2), "clicked", G_CALLBACK(on_button_j2_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtomJ2\".\n");
        return 1;
    }

    if (buttonJA != NULL) {
        g_signal_connect(G_OBJECT(buttonJA), "clicked", G_CALLBACK(on_button_ja_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"ButtomJA\".\n");
        return 1;
    }





    /* WINDOW 4 */
    image_widget = GTK_WIDGET(gtk_builder_get_object(builder, "ImagenWindow5"));
    connect_tablero_buttons();

    // Barra de Menú
    // quit
    GtkWidget *file_quit_menu_item4 = GTK_WIDGET(gtk_builder_get_object(builder, "quit4"));
    if (file_quit_menu_item4 == NULL) {
    	g_print("Error: No se pudo obtener el elemento del menú \"Quit\" en window4.\n");
        return 1;
    }
    g_signal_connect(G_OBJECT(file_quit_menu_item4), "activate", G_CALLBACK(on_menu_file_quit_activate4), NULL);


    // new and inicio
    GtkWidget *new_game_warning = GTK_WIDGET(gtk_builder_get_object(builder, "newgame4"));
    if (new_game_warning == NULL) {
    	g_print("Error: No se pudo obtener el elemento del menú \"new game\" en window4.\n");
        return 1;
    }
    g_signal_connect(G_OBJECT(new_game_warning), "activate", G_CALLBACK(on_menu_file_new_activate), NULL);

    GtkWidget *inicio_return_warning = GTK_WIDGET(gtk_builder_get_object(builder, "home4"));
    if (inicio_return_warning == NULL) {
    	g_print("Error: No se pudo obtener el elemento del menú \"inicio\" en window4.\n");
        return 1;
    }
    g_signal_connect(G_OBJECT(inicio_return_warning), "activate", G_CALLBACK(on_menu_file_home_activate), NULL);


    // about
    GtkWidget *file_about_menu_item4 = GTK_WIDGET(gtk_builder_get_object(builder, "abou4"));
    if (file_about_menu_item4 != NULL) {
        g_signal_connect(G_OBJECT(file_about_menu_item4), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú file\".\n");
    return 1;
    }

    GtkWidget *about_about_menu_item4 = GTK_WIDGET(gtk_builder_get_object(builder, "abo4"));
    if (about_about_menu_item4 != NULL) {
    	g_signal_connect(G_OBJECT(about_about_menu_item4), "activate", G_CALLBACK(on_menu_about_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"About del menú About\".\n");
    return 1;
    }


    // help
    GtkWidget *file_help_menu_item4 = GTK_WIDGET(gtk_builder_get_object(builder, "hel4"));
    if (file_help_menu_item4 != NULL) {
    	g_signal_connect(G_OBJECT(file_help_menu_item4), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú file\".\n");
    return 1;
    }

    GtkWidget *help_help_menu_item4 = GTK_WIDGET(gtk_builder_get_object(builder, "he4"));
    if (help_help_menu_item4 != NULL) {
    	g_signal_connect(G_OBJECT(help_help_menu_item4), "activate", G_CALLBACK(on_menu_help_activate), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"Help del menú Help\".\n");
    return 1;
    }


    // Estadisticas
    GtkWidget *estadisticas_menu_item4 = GTK_WIDGET(gtk_builder_get_object(builder, "estadisticas4"));
    if (estadisticas_menu_item4 != NULL) {
    	g_signal_connect(G_OBJECT(estadisticas_menu_item4), "activate", G_CALLBACK(on_menu_stats_activate), NULL);
    } else {
    	g_print("Error: No se pudo obtener el botón \"Estadísticas de W4\".\n");
    return 1;
    }


    for (char letra = 'A'; letra <= 'E'; letra++) {
        for (int i = 1; i <= 5; i++) {
            gchar *button_name = g_strdup_printf("Button%c%d", letra, i);
            GtkWidget *button = GTK_WIDGET(gtk_builder_get_object(builder, button_name));

            g_signal_connect(button, "clicked", G_CALLBACK(on_button_tablero_clicked), NULL);
            g_free(button_name);
        }
    }

    GtkWidget *button_captura = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonCaptura"));
    g_signal_connect(button_captura, "clicked", G_CALLBACK(on_button_captura_clicked), NULL);





    /* WINDOW 6 */
    // Barra de Menú
        // quit
        GtkWidget *file_quit_menu_item6 = GTK_WIDGET(gtk_builder_get_object(builder, "quit5"));
        if (file_quit_menu_item6 == NULL) {
            g_print("Error: No se pudo obtener el elemento del menú \"Quit\" en window6.\n");
            return 1;
        }
        g_signal_connect(G_OBJECT(file_quit_menu_item6), "activate", G_CALLBACK(on_menu_file_quit_activate6), NULL);


        // about
        GtkWidget *file_about_menu_item6 = GTK_WIDGET(gtk_builder_get_object(builder, "abou5"));
        if (file_about_menu_item6 != NULL) {
        	g_signal_connect(G_OBJECT(file_about_menu_item6), "activate", G_CALLBACK(on_menu_about_activate), NULL);
        } else {
        	g_print("Error: No se pudo obtener el botón \"About del menú file\".\n");
        return 1;
        }

        GtkWidget *about_about_menu_item6 = GTK_WIDGET(gtk_builder_get_object(builder, "abo5"));
        if (about_about_menu_item6 != NULL) {
            g_signal_connect(G_OBJECT(about_about_menu_item6), "activate", G_CALLBACK(on_menu_about_activate), NULL);
        } else {
            g_print("Error: No se pudo obtener el botón \"About del menú About\".\n");
        return 1;
        }


        // help
        GtkWidget *file_help_menu_item5 = GTK_WIDGET(gtk_builder_get_object(builder, "hel5"));
        if (file_help_menu_item5 != NULL) {
        	g_signal_connect(G_OBJECT(file_help_menu_item5), "activate", G_CALLBACK(on_menu_help_activate), NULL);
        } else {
        	g_print("Error: No se pudo obtener el botón \"Help del menú file\".\n");
        return 1;
        }

        GtkWidget *help_help_menu_item6 = GTK_WIDGET(gtk_builder_get_object(builder, "he5"));
        if (help_help_menu_item6 != NULL) {
            g_signal_connect(G_OBJECT(help_help_menu_item6), "activate", G_CALLBACK(on_menu_help_activate), NULL);
        } else {
            g_print("Error: No se pudo obtener el botón \"Help del menú Help\".\n");
        return 1;
        }


    // return
    GtkWidget *button_returnW6 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonVolverW6"));
    if (button_returnW6 != NULL) {
        g_signal_connect(G_OBJECT(button_returnW6), "clicked", G_CALLBACK(on_button_returnw6_clicked), NULL);
    } else {
        g_print("Error: No se pudo obtener el botón \"RETURN W6\".\n");
        return 1;
    }


    gtk_widget_show_all(window1);
    gtk_main();

    return 0;
}





/* FUNCIONES DE BARRA DE MENÚ */
void on_menu_help_activate(GtkMenuItem *menuitem, gpointer user_data) {
    gtk_widget_show_all(helpWindow);
}

void on_menu_about_activate(GtkMenuItem *menuitem, gpointer user_data) {
    gtk_widget_show_all(aboutWindow);
}

void on_menu_stats_activate(GtkMenuItem *menuitem, gpointer user_data) {
    gtk_widget_show_all(window6);
}



/* FUNCIONES DE WINDOW 1*/
void on_menu_file_quit_activate1(GtkMenuItem *menuitem, gpointer user_data) {
	hide_and_destroy_if_valid(window1);
	funcion_que_muestra_y_destruye();
}

void on_button_play_clicked(GtkButton *button, gpointer user_data) {
	gtk_widget_hide(window1);
    gtk_widget_show_all(window2);
}





/* FUNCIONES DE WINDOW 2 */
void on_menu_file_quit_activate2(GtkMenuItem *menuitem, gpointer user_data) {
	hide_and_destroy_if_valid(window2);
	funcion_que_muestra_y_destruye();
}

void ocultar_elementos(GtkLabel *label, GtkEntry *entry, gpointer data) {
    // Ocultar el label y el entry
    gtk_widget_hide(GTK_WIDGET(label));
    gtk_widget_hide(GTK_WIDGET(entry));
}

void mostrar_elementos(GtkLabel *label, GtkEntry *entry, gpointer data){
	 // Mostrar el label y el entry
	 gtk_widget_show(GTK_WIDGET(label));
	 gtk_widget_show(GTK_WIDGET(entry));
}
void cambiar_label_nombre(GtkLabel *label1, GtkLabel *label2, GtkLabel *labeljugador1, GtkLabel *labeljugador2, GtkEntry *entry1,  GtkEntry *entry2, gpointer data){
	const gchar *label1_modo2 = "Humano";
	const gchar *label2_modo1 = "PC Rival";
	const gchar *labeljugador1_modo2 = "HUMANO";
	const gchar *labeljugador2_modo2 = "IA COMPU"; //Cambiar con el nombre de la IA
	const gchar *labeljugador1_modo1 = "IA COMPU";
	const gchar *labeljugador2_modo1 = "PC RIVAL";

	if (modo==2){
		// Cambiar el texto del label
		gtk_label_set_text(label1, label1_modo2);
		ocultar_elementos(label2, entry2, builder);
		gtk_label_set_text(labeljugador1, labeljugador1_modo2);
		gtk_label_set_text(labeljugador2, labeljugador2_modo2);

	}
	else if(modo==1){
		mostrar_elementos(label2, entry2 , builder);
		ocultar_elementos(label1, entry1, builder);
		// Cambiar el texto del label
		gtk_label_set_text(label2, label2_modo1);
		gtk_label_set_text(labeljugador1, labeljugador1_modo1);
		gtk_label_set_text(labeljugador2, labeljugador2_modo1);
	}
}



void on_button_cvsc_clicked(GtkButton *button, gpointer user_data) {
	GtkWidget *button_start = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonStartW3"));
	GtkLabel *label1 = GTK_LABEL(gtk_builder_get_object(builder, "NombreJ1"));
	GtkLabel *label2 = GTK_LABEL(gtk_builder_get_object(builder, "NombreJ2"));
	GtkEntry *entry1 = GTK_ENTRY(gtk_builder_get_object(builder, "Entry1"));
	GtkEntry *entry2 = GTK_ENTRY(gtk_builder_get_object(builder, "Entry2"));
	GtkLabel *labeljugador1 = GTK_LABEL(gtk_builder_get_object(builder, "labeljugador1"));
	GtkLabel *labeljugador2 = GTK_LABEL(gtk_builder_get_object(builder, "labeljugador2"));
	modo=1;
	gtk_widget_hide(window2);
    gtk_widget_show_all(window3);
    cambiar_label_nombre(label1, label2, labeljugador1, labeljugador2, entry1, entry2, builder);
    gtk_widget_set_sensitive(button_start, FALSE);

}

void on_button_hvsc_clicked(GtkButton *button, gpointer user_data) {
	GtkWidget *button_start = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonStartW3"));
	GtkLabel *label1 = GTK_LABEL(gtk_builder_get_object(builder, "NombreJ1"));
	GtkLabel *label2 = GTK_LABEL(gtk_builder_get_object(builder, "NombreJ2"));
	GtkEntry *entry1 = GTK_ENTRY(gtk_builder_get_object(builder, "Entry1"));
	GtkEntry *entry2 = GTK_ENTRY(gtk_builder_get_object(builder, "Entry2"));
	GtkLabel *labeljugador1 = GTK_LABEL(gtk_builder_get_object(builder, "labeljugador1"));
	GtkLabel *labeljugador2 = GTK_LABEL(gtk_builder_get_object(builder, "labeljugador2"));
	modo=2;
	gtk_widget_hide(window2);
    gtk_widget_show_all(window3);
    cambiar_label_nombre(label1, label2, labeljugador1, labeljugador2, entry1, entry2, builder);
    gtk_widget_set_sensitive(button_start, FALSE);

}







/* FUNCIONES DE WINDOW 3 */
void on_menu_file_quit_activate3(GtkMenuItem *menuitem, gpointer user_data) {
	hide_and_destroy_if_valid(window3);
	funcion_que_muestra_y_destruye();
}

void on_button_return_clicked(GtkButton *button, gpointer user_data) {
	gtk_widget_hide(window3);
    gtk_widget_show_all(window2);
}

static void on_accept_button_clicked(GtkWidget *widget, gpointer user_data) {
    gtk_widget_destroy(GTK_WIDGET(user_data));
}


void show_custom_dialog(const gchar *format, ...) {
    // Crear un buffer para el mensaje formateado
    gchar *message_buffer;

    // Usar la función g_strdup_printf para formatear el mensaje
    va_list args;
    va_start(args, format);
    message_buffer = g_strdup_vprintf(format, args);
    va_end(args);

    GtkWidget *dialog;
    GtkWidget *content_area;
    GtkWidget *label;
    GtkWidget *accept_button;

     // Create a modal dialog
     dialog = gtk_dialog_new_with_buttons("Configuración del juego",
                                          GTK_WINDOW(gtk_widget_get_toplevel(GTK_WIDGET(window4))),  // Parent window
                                          GTK_DIALOG_MODAL,
                                          "_OK", GTK_RESPONSE_OK,
                                          NULL);

     // Set a default size for the dialog
     gtk_window_set_default_size(GTK_WINDOW(dialog), 300, 100);

     // Centrar el diálogo en la pantalla
     gtk_window_set_position(GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);


     // Get the content area of the dialog
     content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));

     // Create a label with the formatted message
     label = gtk_label_new(message_buffer);
     gtk_container_add(GTK_CONTAINER(content_area), label);
     gtk_widget_show(label);

     // Connect the "clicked" signal of the "OK" button
     accept_button = gtk_dialog_get_widget_for_response(GTK_DIALOG(dialog), GTK_RESPONSE_OK);
     g_signal_connect(G_OBJECT(accept_button), "clicked", G_CALLBACK(on_accept_button_clicked), dialog);

     // Free the memory of the message buffer
     g_free(message_buffer);

     // Show all components of the dialog
     gtk_widget_show_all(dialog);

     // Run the dialog in a modal state
     gtk_dialog_run(GTK_DIALOG(dialog));

}

void button_start_info(){

	GtkWidget *Entry1 = GTK_WIDGET(gtk_builder_get_object(builder, "Entry1"));
	GtkWidget *Entry2 = GTK_WIDGET(gtk_builder_get_object(builder, "Entry2"));

	// Obtener textos de los entrys
	const gchar *entry1_text = gtk_entry_get_text(GTK_ENTRY(Entry1));
	const gchar *entry2_text = gtk_entry_get_text(GTK_ENTRY(Entry2));


	char colorstr[20];
	char iniciastr[20];
	if (color==1){
		snprintf(colorstr, sizeof(colorstr), "Rojo");
	}
	else if (color==2){
		snprintf(colorstr, sizeof(colorstr), "Azul");
	}
	else{
		snprintf(colorstr, sizeof(colorstr), "Aleatorio");
	}


	if (modo==1){
		if (inicia==1){
			snprintf(iniciastr, sizeof(iniciastr), "IA Compu");
		}
		else if (inicia==2){
			snprintf(iniciastr, sizeof(iniciastr), "%s", entry2_text );
		}
		else{
			snprintf(iniciastr, sizeof(iniciastr), "Aleatorio");
		}
		show_custom_dialog("Inicia la partida: %s\n IA Compu juega con el dado de color: %s", iniciastr, colorstr);
	}
	else if (modo==2){
		if (inicia==1){
			snprintf(iniciastr, sizeof(iniciastr), "%s", entry1_text );
		}
		else if (inicia==2){
			snprintf(iniciastr, sizeof(iniciastr), "IA Compu");
		}
		else{
			snprintf(iniciastr, sizeof(iniciastr), "Aleatorio");
		}
		show_custom_dialog("Inicia la partida: %s\n%s juega con el dado de color: %s", iniciastr, entry1_text, colorstr);
	}


}

void cambiar_label_turno(GtkLabel *labelTurno1, GtkLabel *labelTurno2, gpointer data){
	 // Llamar a la función para mostrar el label correspondiente
		GtkWidget *Entry1 = GTK_WIDGET(gtk_builder_get_object(builder, "Entry1"));
		//GtkWidget *Entry2 = GTK_WIDGET(gtk_builder_get_object(builder, "Entry2"));

		// Obtener textos de los entrys
		const gchar *entry1_text = gtk_entry_get_text(GTK_ENTRY(Entry1));
		//const gchar *entry2_text = gtk_entry_get_text(GTK_ENTRY(Entry2));

		int contdadosochos=0;
		int contdadossietes=0;
		 for (int i=0; i<5; i++ )
		 {
			 for (int j=0; j<5; j++)
			 {
		            if(tableroposic[i][j]==8)
		            {
		                contdadosochos++;
		            }
		            else if (tableroposic[i][j]==7)
		            {
		                contdadossietes++;
		            }
		       }
		 }

		 int contdadoscompu=25-contdadosochos;
		 int contdadosusuario=25-contdadossietes;



		const gchar *TextoTurno2 =  g_strdup_printf("Turno IA COMPU (tiene %d dados disponibles)", contdadoscompu);
		const gchar *TextoTurno1 = g_strdup_printf("Turno %s (tiene %d dados disponibles)", entry1_text, contdadosusuario);

		gtk_label_set_text(labelTurno1, TextoTurno1);
		gtk_label_set_text(labelTurno2, TextoTurno2);


}

void on_button_start_clicked(GtkButton *button, gpointer user_data) {
	gtk_widget_hide(window3);
    gtk_widget_show_all(window4);
    cambiar_label_turno(labelTurnoJugador1, labelTurnoJugador2, builder);
    gtk_widget_hide(GTK_WIDGET(labelTurnoJugador1));
    gtk_widget_hide(GTK_WIDGET(labelTurnoJugador2));

    button_start_info();

	GtkWidget *captura_button = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonCaptura"));
	if (captura_button != NULL) {
	    gtk_widget_set_sensitive(captura_button, FALSE);
	}
    if (inicia==2){
    	on_button_tableroj2start_clicked();
    	gtk_widget_show(GTK_WIDGET(labelTurnoJugador1));
    }
    else if (inicia==1){
	   gtk_widget_show(GTK_WIDGET(labelTurnoJugador1));
    }

}

void update_start_button_sensitive() {
    gboolean group1_presionado = rojo_presionado || azul_presionado || aleatorio_presionado;
    gboolean group2_presionado = J1_presionado || J2_presionado || JA_presionado;

    // Verifica si al menos uno de cada grupo está presionado
    gboolean any_button_presionado = group1_presionado && group2_presionado;

    // Obtén el botón "Start" desde el builder
    GtkWidget *button_start = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonStartW3"));

    // Actualiza la sensibilidad del botón "Start" según el estado de los demás botones
    gtk_widget_set_sensitive(button_start, any_button_presionado);
}

void actualizar_apariencia_botones() {
    // Restaurar la apariencia predeterminada de todos los botones y etiquetas
    gtk_button_set_relief(GTK_BUTTON(rojo_button), GTK_RELIEF_NONE);
    gtk_button_set_relief(GTK_BUTTON(azul_button), GTK_RELIEF_NONE);
    gtk_button_set_relief(GTK_BUTTON(aleatorio_button), GTK_RELIEF_NONE);

    if (rojo_presionado) {
        gtk_button_set_relief(GTK_BUTTON(rojo_button), GTK_RELIEF_NORMAL);
    }

    if (azul_presionado) {
        gtk_button_set_relief(GTK_BUTTON(azul_button), GTK_RELIEF_NORMAL);
    }

    if (aleatorio_presionado) {
        gtk_button_set_relief(GTK_BUTTON(aleatorio_button), GTK_RELIEF_NORMAL);
    }
}

void actualizar_apariencia_botones_inicia() {
    // Restaurar la apariencia predeterminada de todos los botones y etiquetas
    gtk_button_set_relief(GTK_BUTTON(buttonJ1), GTK_RELIEF_NONE);
    gtk_button_set_relief(GTK_BUTTON(buttonJ2), GTK_RELIEF_NONE);
    gtk_button_set_relief(GTK_BUTTON(buttonJA), GTK_RELIEF_NONE);

    if (J1_presionado) {
        gtk_button_set_relief(GTK_BUTTON(buttonJ1), GTK_RELIEF_NORMAL);
    }

    if (J2_presionado) {
        gtk_button_set_relief(GTK_BUTTON(buttonJ2), GTK_RELIEF_NORMAL);
    }

    if (JA_presionado) {
        gtk_button_set_relief(GTK_BUTTON(buttonJA), GTK_RELIEF_NORMAL);
    }
}

void on_button_rojo_clicked(GtkButton *button, gpointer user_data) {
	 rojo_presionado = TRUE;
	 azul_presionado = FALSE;
	 aleatorio_presionado = FALSE;
	 actualizar_apariencia_botones();
	 update_start_button_sensitive();
	 obtenerColor();
}

void on_button_azul_clicked(GtkButton *button, gpointer user_data) {
	 rojo_presionado = FALSE;
	 azul_presionado = TRUE;
	 aleatorio_presionado = FALSE;
	 actualizar_apariencia_botones();
	 update_start_button_sensitive();
	 obtenerColor();
}

void on_button_aleatorio_clicked(GtkButton *button, gpointer user_data) {
	 rojo_presionado = FALSE;
	 azul_presionado = FALSE;
	 aleatorio_presionado = TRUE;
	 actualizar_apariencia_botones();
	 update_start_button_sensitive();
	 obtenerColor();
}

void on_button_j1_clicked(GtkButton *button, gpointer user_data) {
	 J1_presionado = TRUE;
	 J2_presionado = FALSE;
	 JA_presionado = FALSE;
	 actualizar_apariencia_botones_inicia();
	 update_start_button_sensitive();
	 obtenerInicia();
}

void on_button_j2_clicked(GtkButton *button, gpointer user_data) {
	 J1_presionado = FALSE;
	 J2_presionado = TRUE;
	 JA_presionado = FALSE;
	 actualizar_apariencia_botones_inicia();
	 update_start_button_sensitive();
	 obtenerInicia();
}

void on_button_ja_clicked(GtkButton *button, gpointer user_data) {
	 J1_presionado = FALSE;
	 J2_presionado = FALSE;
	 JA_presionado = TRUE;
	 actualizar_apariencia_botones_inicia();
	 update_start_button_sensitive();
	 obtenerInicia();
}

void obtenerColor() {
    if (rojo_presionado) {
        color = 1;
    } else if (azul_presionado) {
        color = 2;
    } else if (aleatorio_presionado) {
        // Genera un número aleatorio entre 1 y 2
        color = (rand() % 2) + 1;
    }
}

void obtenerInicia() {
    if (J1_presionado) {
        inicia = 1;
    } else if (J2_presionado) {
        inicia = 2;
    } else if (JA_presionado) {
        // Genera un número aleatorio entre 1 y 2
        inicia = (rand() % 2) + 1;
    }
}





/* FUNCIONES DE WINDOW 5 */
void on_menu_file_quit_activate5(GtkMenuItem *menuitem, gpointer user_data) {
	hide_and_destroy_if_valid(window5);
	funcion_que_muestra_y_destruye();
}






/* FUNCIONES DE WINDOW 6 */
void on_menu_file_quit_activate6(GtkMenuItem *menuitem, gpointer user_data) {
	hide_and_destroy_if_valid(window6);
	funcion_que_muestra_y_destruye();
}

void on_button_returnw6_clicked(GtkButton *button, gpointer user_data) {
	gtk_widget_hide(window6);
}




/* FUNCIONES DE WINDOW 7 */
// Función para destruir la ventana
gboolean destroy_window(GtkWidget *window) {
    gtk_widget_destroy(window);
    return G_SOURCE_REMOVE;  // Elimina el evento después de ejecutarse
}

// Función que muestra la ventana y programa su destrucción después de cierto tiempo
void show_and_destroy_window(GtkWidget *window) {
    // Muestra la ventana
    gtk_widget_show_all(window);

    // Programa la destrucción después de 3000 milisegundos (3 segundos)
    g_timeout_add(1500, (GSourceFunc)destroy_window, window);
    g_timeout_add(1501, (GSourceFunc)gtk_main_quit, NULL);
}

// Ejemplo de cómo llamar a show_and_destroy_window desde otra función
void funcion_que_muestra_y_destruye() {
    // Obtén la ventana, por ejemplo, window7
    GtkWidget *window7 = GTK_WIDGET(gtk_builder_get_object(builder, "window7"));

    // Llama a la función que muestra la ventana y programa su destrucción
    show_and_destroy_window(window7);
}





/* FUNCIONES DE BARRA DE MENÚ */
void on_about_close_clicked(GtkButton *button, gpointer user_data) {
	gtk_widget_hide(aboutWindow);
}

void on_help_close_clicked(GtkButton *button, gpointer user_data) {
	gtk_widget_hide(helpWindow);
}

void on_window5_inicio_clicked(GtkButton *button, gpointer user_data) {
	gtk_widget_hide(window5);
	gtk_widget_hide(window4);
	gtk_widget_show_all(window2);
	for (int i=0; i<TAM_TABLERO; i++)
		    {
		        for (int j=0; j<TAM_TABLERO; j++)
		        {
		            tablero[i][j]=0;
		        }
		    }
			for (int i=0; i<TAM_TABLERO; i++)
		    {
		        for (int j=0; j<TAM_TABLERO; j++)
		        {
		            tableroposic[i][j]=0;
		        }
		    }



}

void on_window5_stats_clicked(GtkButton *button, gpointer user_data) {
	gtk_widget_hide(window5);
	gtk_widget_show_all(window6);
}

gboolean on_window5_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data) {
	gtk_widget_hide(widget);  // Oculta la ventana About en lugar de destruirla
    return TRUE;  // Impide el manejo predeterminado del evento (evita que la ventana se destruya)
}


gboolean on_about_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data) {
    gtk_widget_hide(widget);  // Oculta la ventana About en lugar de destruirla
    return TRUE;  // Impide el manejo predeterminado del evento (evita que la ventana se destruya)
}

gboolean on_help_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data) {
    gtk_widget_hide(widget);  // Oculta la ventana Help en lugar de destruirla
    return TRUE;  // Impide el manejo predeterminado del evento (evita que la ventana se destruya)
}

gboolean on_window6_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data) {
    gtk_widget_hide(widget);  // Oculta la ventana About en lugar de destruirla
    return TRUE;  // Impide el manejo predeterminado del evento (evita que la ventana se destruya)
}

gboolean on_new_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data) {
    gtk_widget_hide(widget);  // Oculta la ventana About en lugar de destruirla
    return TRUE;  // Impide el manejo predeterminado del evento (evita que la ventana se destruya)
}

gboolean on_home_window_delete_event(GtkWidget *widget, GdkEvent *event, gpointer user_data) {
    gtk_widget_hide(widget);  // Oculta la ventana About en lugar de destruirla
    return TRUE;  // Impide el manejo predeterminado del evento (evita que la ventana se destruya)
}



























/* FUNCIONES DE WINDOW 4 */
void on_menu_file_quit_activate4(GtkMenuItem *menuitem, gpointer user_data) {
	hide_and_destroy_if_valid(window4);
	funcion_que_muestra_y_destruye();
}

void on_menu_file_new_activate(GtkMenuItem *menuitem, gpointer user_data) {
	if (flag==1){
		gtk_widget_hide(window4);
		gtk_widget_show(window2);
		for (int i=0; i<TAM_TABLERO; i++)
	    {
	        for (int j=0; j<TAM_TABLERO; j++)
	        {
	            tablero[i][j]=0;
	        }
	    }
		for (int i=0; i<TAM_TABLERO; i++)
	    {
	        for (int j=0; j<TAM_TABLERO; j++)
	        {
	            tableroposic[i][j]=0;
	        }
	    }

	}
	if (flag==0){
		gtk_widget_show(newwarning);
	}
}

void on_menu_file_home_activate(GtkMenuItem *menuitem, gpointer user_data) {
	if (flag==1){
		gtk_widget_hide(window4);
		gtk_widget_show(window2);
		for (int i=0; i<TAM_TABLERO; i++)
	    {
	        for (int j=0; j<TAM_TABLERO; j++)
	        {
	            tablero[i][j]=0;
	        }
	    }
		for (int i=0; i<TAM_TABLERO; i++)
	    {
	        for (int j=0; j<TAM_TABLERO; j++)
	        {
	            tableroposic[i][j]=0;
	        }
	    }

	}
	if (flag==0){
		gtk_widget_show(mainwarning);
	}
}

void on_aceptar_new_clicked(GtkMenuItem *menuitem, gpointer user_data) {
		gtk_widget_hide(window4);
		gtk_widget_hide(newwarning);
		gtk_widget_show(window2);
		for (int i=0; i<TAM_TABLERO; i++)
	    {
	        for (int j=0; j<TAM_TABLERO; j++)
	        {
	            tablero[i][j]=0;
	        }
	    }
		for (int i=0; i<TAM_TABLERO; i++)
	    {
	        for (int j=0; j<TAM_TABLERO; j++)
	        {
	            tableroposic[i][j]=0;
	        }
	    }
	}

void on_cancelar_new_clicked(GtkMenuItem *menuitem, gpointer user_data) {
		gtk_widget_hide(newwarning);
}

void on_cancelar_home_clicked(GtkMenuItem *menuitem, gpointer user_data) {
		gtk_widget_hide(mainwarning);
}

void on_aceptar_home_clicked(GtkMenuItem *menuitem, gpointer user_data) {
		gtk_widget_hide(window4);
		gtk_widget_hide(mainwarning);
		gtk_widget_show(window2);
		for (int i=0; i<TAM_TABLERO; i++)
	    {
	        for (int j=0; j<TAM_TABLERO; j++)
	        {
	            tablero[i][j]=0;
	        }
	    }
		for (int i=0; i<TAM_TABLERO; i++)
	    {
	        for (int j=0; j<TAM_TABLERO; j++)
	        {
	            tableroposic[i][j]=0;
	        }
	    }
	}

/* Función para conectar los botones del menú "Tablero" a las funciones correspondientes */

void connect_tablero_buttons() {
    GtkWidget *tablero_predeterminado_button = GTK_WIDGET(gtk_builder_get_object(builder, "tableropredeterminado"));
    GtkWidget *tablero_futbol_button = GTK_WIDGET(gtk_builder_get_object(builder, "tablerofutbol"));
    GtkWidget *tablero_swiftie_button = GTK_WIDGET(gtk_builder_get_object(builder, "tableroswiftie"));
    GtkWidget *tablero_estrellas_button = GTK_WIDGET(gtk_builder_get_object(builder, "tableroestrellas"));
    GtkWidget *tablero_atardecer_button = GTK_WIDGET(gtk_builder_get_object(builder, "tableroatardecer"));

    g_signal_connect(G_OBJECT(tablero_predeterminado_button), "activate", G_CALLBACK(cambiar_fondo_predeterminado), NULL);
    g_signal_connect(G_OBJECT(tablero_futbol_button), "activate", G_CALLBACK(cambiar_fondo_futbol), NULL);
    g_signal_connect(G_OBJECT(tablero_swiftie_button), "activate", G_CALLBACK(cambiar_fondo_swiftie), NULL);
    g_signal_connect(G_OBJECT(tablero_estrellas_button), "activate", G_CALLBACK(cambiar_fondo_estrellas), NULL);
    g_signal_connect(G_OBJECT(tablero_atardecer_button), "activate", G_CALLBACK(cambiar_fondo_atardecer), NULL);



}

/* Funciones para cambiar el fondo de window4 según la opción de Tablero */

void cambiar_fondo_predeterminado() {
    cambiar_imagen_window4("1.png");
}

void cambiar_fondo_futbol() {
    cambiar_imagen_window4("2.png");
}

void cambiar_fondo_swiftie() {
    cambiar_imagen_window4("3.png");
}

void cambiar_fondo_estrellas() {
    cambiar_imagen_window4("4.png");
}

void cambiar_fondo_atardecer() {
    cambiar_imagen_window4("5.png");
}

void cambiar_imagen_window4(const gchar *imagen_path) {
    GtkWidget *image_widget = GTK_WIDGET(gtk_builder_get_object(builder, "ImagenWindow5"));
    if (image_widget != NULL) {
        GdkPixbuf *pixbuf = gdk_pixbuf_new_from_file(imagen_path, NULL);
        if (pixbuf != NULL) {
            gtk_image_set_from_pixbuf(GTK_IMAGE(image_widget), pixbuf);
            g_object_unref(pixbuf);
        } else {
            g_print("Error: No se pudo cargar la imagen: %s\n", imagen_path);
        }
    } else {
        g_print("Error: No se pudo obtener el widget de imagen en window4.\n");
    }
}


// Funciones que actualizan el tablero

void obtenerCoordenadasDesdeBoton(GtkWidget *button, int *coordenadas) {
	// Obtener el nombre del botón clickeado
    const gchar *button_name = gtk_widget_get_name(button);

    if (button_name== NULL || strncmp(button_name, "Button", 6) != 0 || button_name[6] < 'A' || button_name[6] > 'E' || button_name[7] < '1' || button_name[7] > '5') {
        fprintf(stderr, "Nombre de botón no válido.\n");
        exit(EXIT_FAILURE);
    }

    coordenadas[1] = (button_name[7] - '0');  // Fila (y)
    coordenadas[0] = button_name[6] - 'A' + 1;     // Columna (x)
}


void label_turno(int num){

	if (num == 1) {
			gtk_widget_hide(GTK_WIDGET(labelTurnoJugador2));
			gtk_widget_show(GTK_WIDGET(labelTurnoJugador1));

	}
	else if (num == 2){
	    	gtk_widget_hide(GTK_WIDGET(labelTurnoJugador1));;
	        gtk_widget_show(GTK_WIDGET(labelTurnoJugador2));;
	}
}

void deshabilitar_botones_tablero(GtkBuilder *builder) {
    for (char fila = 'A'; fila <= 'E'; ++fila) {
        for (int columna = 1; columna <= 5; ++columna) {
            // Construir el nombre del botón (por ejemplo, ButtonA1)
            char nombre_boton[20];
            sprintf(nombre_boton, "Button%c%d", fila, columna);

            // Obtener el widget del builder utilizando el nombre
            GtkWidget *boton = GTK_WIDGET(gtk_builder_get_object(builder, nombre_boton));

            // Deshabilitar el botón si se encontró
            if (boton != NULL) {
                gtk_widget_set_sensitive(boton, FALSE);
            }
        }
    }
}

void activar_botones(int matrizcapturas[4][3]) {
    for (int i = 0; i < 4; i++) {
        if (matrizcapturas[i][0]) {
            int letra = matrizcapturas[i][1];
            int numero = matrizcapturas[i][2];

            char letra_char = 'A' + letra - 1; // Convertir 1 a A, 2 a B, etc.
            char nombre_boton[20]; // Ajusta el tamaño según tus necesidades
            snprintf(nombre_boton, sizeof(nombre_boton), "Button%c%d", letra_char, numero);

            GtkWidget *boton = GTK_WIDGET(gtk_builder_get_object(builder, nombre_boton));
            if (boton != NULL) {
                gtk_widget_set_sensitive(boton, TRUE); // Activar el botón
            } else {
                g_print("Error: No se pudo obtener el botón %s.\n", nombre_boton);
            }
        }
    }
}

void on_button_tablero_clicked(GtkWidget *button, gpointer user_data) {
    if (estado == 0) {
        GtkWidget *captura_button = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonCaptura"));
        if (captura_button != NULL) {
            gtk_widget_set_sensitive(captura_button, FALSE);
        }
        obtenerCoordenadasDesdeBoton(button, botonaux);
        obtenerCoordenadasDesdeBoton(button, coordenadas);
        revisioncapturas(7, color, coordenadas);

        if (posiblescapturas < 3) {
            principalgtk(coordenadas, color, botonaux);
        }
        if (posiblescapturas > 2) {
            estado = 1;
            deshabilitar_botones_tablero(builder);
            activar_botones(matrizcapturas);
        }
    }
    if (estado == 1) {
        // Cambiar el relieve del botón
        if (gtk_button_get_relief(GTK_BUTTON(button)) == GTK_RELIEF_NONE) {
            gtk_button_set_relief(GTK_BUTTON(button), GTK_RELIEF_HALF);
        } else {
            gtk_button_set_relief(GTK_BUTTON(button), GTK_RELIEF_NONE);
        }
        ajustar_sensibilidad_button_captura(button);
    }
    g_timeout_add(TIEMPO+1, evaluar_flag, NULL);


}

void cambiar_label_ganador(GtkLabel *ganador, gpointer data){
	 // Llamar a la función para mostrar el label correspondiente
		GtkWidget *Entry1 = GTK_WIDGET(gtk_builder_get_object(builder, "Entry1"));
		//GtkWidget *Entry2 = GTK_WIDGET(gtk_builder_get_object(builder, "Entry2"));

		// Obtener textos de los entrys
		const gchar *entry1_text = gtk_entry_get_text(GTK_ENTRY(Entry1));
		//const gchar *entry2_text = gtk_entry_get_text(GTK_ENTRY(Entry2));
		const gchar *TextoGanadorCompu = "¡El ganador del juego es IA COMPU!";
		const gchar *TextoGanadorUsuario = g_strdup_printf("¡El ganador del juego es %s!", entry1_text);
		const gchar *TextoEmpate = "¡Empate parcial, partida inconclusa!";


		int textoganador=Ganador();
		if (textoganador==1){
			gtk_label_set_text(ganador, TextoGanadorCompu);
		}
		else if (textoganador==2){
			gtk_label_set_text(ganador, TextoGanadorUsuario);
		}
		else if (textoganador==0){
			gtk_label_set_text(ganador, TextoEmpate);
		}



}
gboolean evaluar_flag(gpointer user_data)
{
	flag=FindelJuego();
	if (flag==1)
	    gtk_widget_show(window5);
		cambiar_label_ganador(LabelGanador, builder);
	return FALSE;
}


void on_button_tableroj2start_clicked() {
	principalgtk1(color);
	actualizarBotones(tablero, tableroposic, color);

}

void ajustar_sensibilidad_button_captura(GtkWidget *button) {
    GtkWidget *captura_button = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonCaptura"));

    // Actualiza contaux según los cambios en el relieve del botón
    if (GTK_IS_BUTTON(button)) {
        if (gtk_button_get_relief(GTK_BUTTON(button)) == GTK_RELIEF_NONE) {
            // Si pasa de con relieve a sin relieve, decrementa contaux
            contaux--;
        } else {
            // Si pasa de sin relieve a con relieve, incrementa contaux
            contaux++;
        }

        // Obtén las coordenadas desde el botón
        int coordenadas[2];
        obtenerCoordenadasDesdeBoton(button, coordenadas);

        // Actualiza sumaaux según los cambios en el relieve del botón
        if (GTK_IS_BUTTON(button)) {
            int valorAntiguo = tablero[5-coordenadas[1]][coordenadas[0]-1];

            // Si el botón pasa a tener relieve, resta el valor antiguo
            if (gtk_button_get_relief(GTK_BUTTON(button)) == GTK_RELIEF_NONE) {
                sumaaux -= valorAntiguo;
            } else {
                // Si pasa de con relieve a sin relieve, suma el valor nuevo
                sumaaux += valorAntiguo;
            }

        }

        // Ajusta la sensibilidad del botón basándote en la condición contaux > 2
        gtk_widget_set_sensitive(captura_button, contaux > 2 && sumaaux < 7);
    }
}

void on_button_captura_clicked(GtkButton *button, gpointer user_data) {
    // Obtener coordenadas de todos los botones con relieve activado
    obtener_coordenadas_con_relieve();
    for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 2; j++) {
                printf("%d\t", coordenadas_con_relieve[i][j]);
            }
            printf("\n");
        }
    quitarRelieveBotones(builder);
    principalgtk(coordenadas, color, botonaux);

    // Actualizar el estado a 0
    estado = 0;
    contaux=0;
    sumaaux=0;
    actualizarBotones(tablero, tableroposic, color);
    GtkWidget *captura_button = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonCaptura"));
    	if (captura_button != NULL) {
    	    gtk_widget_set_sensitive(captura_button, FALSE);}

}

void obtener_coordenadas_con_relieve() {
    int indice_coordenadas = 0; // Índice para la matriz de coordenadas

    for (char letra = 'A'; letra <= 'E'; letra++) {
        for (int numero = 1; numero <= 5; numero++) {
            // Obtener el nombre del botón
            char button_name[20];
            sprintf(button_name, "Button%c%d", letra, numero);

            // Obtener el widget del botón
            GtkWidget *button = GTK_WIDGET(gtk_builder_get_object(builder, button_name));

            // Verificar si el botón tiene relieve activado
            if (GTK_IS_BUTTON(button) && gtk_button_get_relief(GTK_BUTTON(button)) != GTK_RELIEF_NONE) {
                // Obtener coordenadas utilizando la función proporcionada
                obtenerCoordenadasDesdeBoton(button, coordenadas_con_relieve[indice_coordenadas]);

                // Incrementar el índice
                indice_coordenadas++;

                // Hacer algo más si es necesario
            }
        }
    }
}

void quitarRelieveBotones(GtkBuilder *builder) {
    for (char letra = 'A'; letra <= 'E'; letra++) {
        for (int i = 1; i <= 5; i++) {
            gchar *button_name = g_strdup_printf("Button%c%d", letra, i);
            GtkWidget *button = GTK_WIDGET(gtk_builder_get_object(builder, button_name));

            if (GTK_IS_BUTTON(button)) {
                // Quuitar el relieve del botón
                gtk_button_set_relief(GTK_BUTTON(button), GTK_RELIEF_NONE);
            }

            g_free(button_name);
        }
    }
}





/* FUNCIONES DE ACTUALIZAR BOTONES */
void actualizarBotonA5(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[0][0];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[0][0];

    // Obtener el widget de imagen
    GtkWidget *imagenA5 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenA5"));
    GtkWidget *botonA5 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonA5"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonA5, FALSE);
        else
        	gtk_widget_set_sensitive(botonA5, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenA5), rutaImagen);
}

void actualizarBotonA4(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[1][0];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[1][0];

    // Obtener el widget de imagen
    GtkWidget *imagenA4 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenA4"));
    GtkWidget *botonA4 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonA4"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
    	gtk_widget_set_sensitive(botonA4, FALSE);
    else
    	gtk_widget_set_sensitive(botonA4, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenA4), rutaImagen);
}

void actualizarBotonA3(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[2][0];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[2][0];

    // Obtener el widget de imagen
    GtkWidget *imagenA3 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenA3"));
    GtkWidget *botonA3 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonA3"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonA3, FALSE);
        else
        	gtk_widget_set_sensitive(botonA3, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenA3), rutaImagen);
}

void actualizarBotonA2(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[3][0];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[3][0];

    // Obtener el widget de imagen
    GtkWidget *imagenA2 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenA2"));
    GtkWidget *botonA2 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonA2"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonA2, FALSE);
        else
        	gtk_widget_set_sensitive(botonA2, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenA2), rutaImagen);
}

void actualizarBotonA1(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[4][0];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[4][0];

    // Obtener el widget de imagen
    GtkWidget *imagenA1 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenA1"));
    GtkWidget *botonA1 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonA1"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonA1, FALSE);
        else
        	gtk_widget_set_sensitive(botonA1, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenA1), rutaImagen);
}

void actualizarBotonB5(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[0][1];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[0][1];

    // Obtener el widget de imagen
    GtkWidget *imagenB5 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenB5"));
    GtkWidget *botonB5 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonB5"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonB5, FALSE);
        else
        	gtk_widget_set_sensitive(botonB5, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenB5), rutaImagen);
}

void actualizarBotonB4(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[1][1];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[1][1];

    // Obtener el widget de imagen
    GtkWidget *imagenB4 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenB4"));
    GtkWidget *botonB4 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonB4"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonB4, FALSE);
        else
        	gtk_widget_set_sensitive(botonB4, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenB4), rutaImagen);
}

void actualizarBotonB3(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[2][1];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[2][1];

    // Obtener el widget de imagen
    GtkWidget *imagenB3 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenB3"));
    GtkWidget *botonB3 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonB3"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonB3, FALSE);
        else
        	gtk_widget_set_sensitive(botonB3, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenB3), rutaImagen);
}

void actualizarBotonB2(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[3][1];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[3][1];

    // Obtener el widget de imagen
    GtkWidget *imagenB2 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenB2"));
    GtkWidget *botonB2 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonB2"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonB2, FALSE);
        else
        	gtk_widget_set_sensitive(botonB2, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenB2), rutaImagen);
}

void actualizarBotonB1(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[4][1];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[4][1];

    // Obtener el widget de imagen
    GtkWidget *imagenB1 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenB1"));
    GtkWidget *botonB1 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonB1"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonB1, FALSE);
        else
        	gtk_widget_set_sensitive(botonB1, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenB1), rutaImagen);
}

void actualizarBotonC5(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[0][2];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[0][2];

    // Obtener el widget de imagen
    GtkWidget *imagenC5 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenC5"));
    GtkWidget *botonC5 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonC5"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonC5, FALSE);
        else
        	gtk_widget_set_sensitive(botonC5, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenC5), rutaImagen);
}

void actualizarBotonC4(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[1][2];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[1][2];

    // Obtener el widget de imagen
    GtkWidget *imagenC4 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenC4"));
    GtkWidget *botonC4 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonC4"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonC4, FALSE);
        else
        	gtk_widget_set_sensitive(botonC4, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenC4), rutaImagen);
}

void actualizarBotonC3(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[2][2];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[2][2];

    // Obtener el widget de imagen
    GtkWidget *imagenC3 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenC3"));
    GtkWidget *botonC3 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonC3"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";


    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonC3, FALSE);
        else
        	gtk_widget_set_sensitive(botonC3, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenC3), rutaImagen);
}

void actualizarBotonC2(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[3][2];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[3][2];

    // Obtener el widget de imagen
    GtkWidget *imagenC2 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenC2"));
    GtkWidget *botonC2 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonC2"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonC2, FALSE);
        else
        	gtk_widget_set_sensitive(botonC2, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenC2), rutaImagen);
}

void actualizarBotonC1(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[4][2];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[4][2];

    // Obtener el widget de imagen
    GtkWidget *imagenC1 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenC1"));
    GtkWidget *botonC1 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonC1"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonC1, FALSE);
        else
        	gtk_widget_set_sensitive(botonC1, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenC1), rutaImagen);
}

void actualizarBotonD5(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[0][3];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[0][3];

    // Obtener el widget de imagen
    GtkWidget *imagenD5 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenD5"));
    GtkWidget *botonD5 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonD5"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonD5, FALSE);
        else
        	gtk_widget_set_sensitive(botonD5, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenD5), rutaImagen);
}

void actualizarBotonD4(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[1][3];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[1][3];

    // Obtener el widget de imagen
    GtkWidget *imagenD4 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenD4"));
    GtkWidget *botonD4 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonD4"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonD4, FALSE);
        else
        	gtk_widget_set_sensitive(botonD4, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenD4), rutaImagen);
}

void actualizarBotonD3(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[2][3];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[2][3];

    // Obtener el widget de imagen
    GtkWidget *imagenD3 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenD3"));
    GtkWidget *botonD3 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonD3"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonD3, FALSE);
        else
        	gtk_widget_set_sensitive(botonD3, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenD3), rutaImagen);
}

void actualizarBotonD2(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[3][3];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[3][3];

    // Obtener el widget de imagen
    GtkWidget *imagenD2 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenD2"));
    GtkWidget *botonD2 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonD2"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonD2, FALSE);
        else
        	gtk_widget_set_sensitive(botonD2, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenD2), rutaImagen);
}

void actualizarBotonD1(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[4][3];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[4][3];

    // Obtener el widget de imagen
    GtkWidget *imagenD1 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenD1"));
    GtkWidget *botonD1 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonD1"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonD1, FALSE);
        else
        	gtk_widget_set_sensitive(botonD1, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenD1), rutaImagen);
}

void actualizarBotonE5(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[0][4];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[0][4];

    // Obtener el widget de imagen
    GtkWidget *imagenE5 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenE5"));
    GtkWidget *botonE5 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonE5"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonE5, FALSE);
        else
        	gtk_widget_set_sensitive(botonE5, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenE5), rutaImagen);
}

void actualizarBotonE4(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[1][4];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[1][4];

    // Obtener el widget de imagen
    GtkWidget *imagenE4 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenE4"));
    GtkWidget *botonE4 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonE4"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonE4, FALSE);
        else
        	gtk_widget_set_sensitive(botonE4, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenE4), rutaImagen);
}

void actualizarBotonE3(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[2][4];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[2][4];

    // Obtener el widget de imagen
    GtkWidget *imagenE3 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenE3"));
    GtkWidget *botonE3 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonE3"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonE3, FALSE);
        else
        	gtk_widget_set_sensitive(botonE3, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenE3), rutaImagen);
}

void actualizarBotonE2(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[3][4];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[3][4];

    // Obtener el widget de imagen
    GtkWidget *imagenE2 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenE2"));
    GtkWidget *botonE2 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonE2"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonE2, FALSE);
        else
        	gtk_widget_set_sensitive(botonE2, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenE2), rutaImagen);
}

void actualizarBotonE1(int tablero[5][5], int tableroposic[5][5], int color) {
    // Obtener el estado de la posición tablero[0][0]
    int estado = tablero[4][4];

    // Obtener el estado de tableroposic[0][0]
    int posicion = tableroposic[4][4];

    // Obtener el widget de imagen
    GtkWidget *imagenE1 = GTK_WIDGET(gtk_builder_get_object(builder, "imagenE1"));
    GtkWidget *botonE1 = GTK_WIDGET(gtk_builder_get_object(builder, "ButtonE1"));

    // Construir el nombre del archivo de imagen
    char *nombreImagen = "inicial.png";

    if (color == 1) {
        if (estado == 1) {
            if (posicion == 7) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 8) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 7) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 8) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 7) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 8) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 7) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 8) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 7) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 8) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 7) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 8) {
                nombreImagen = "azul6.png";
            }
        }
    } else if (color == 2) {
        // Código similar pero intercambiando los valores de 7 y 8
        // según las condiciones especificadas

    	if (estado == 1) {
            if (posicion == 8) {
                nombreImagen = "rojo1.png";
            } else if (posicion == 7) {
                nombreImagen = "azul1.png";
            }
        } else if (estado == 2) {
            if (posicion == 8) {
                nombreImagen = "rojo2.png";
            } else if (posicion == 7) {
                nombreImagen = "azul2.png";
            }
        } else if (estado == 3) {
            if (posicion == 8) {
                nombreImagen = "rojo3.png";
            } else if (posicion == 7) {
                nombreImagen = "azul3.png";
            }
        } else if (estado == 4) {
            if (posicion == 8) {
                nombreImagen = "rojo4.png";
            } else if (posicion == 7) {
                nombreImagen = "azul4.png";
            }
        } else if (estado == 5) {
            if (posicion == 8) {
                nombreImagen = "rojo5.png";
            } else if (posicion == 7) {
                nombreImagen = "azul5.png";
            }
        } else if (estado == 6) {
            if (posicion == 8) {
                nombreImagen = "rojo6.png";
            } else if (posicion == 7) {
                nombreImagen = "azul6.png";
            }
        }
    }
    if (estado != 0)
        	gtk_widget_set_sensitive(botonE1, FALSE);
        else
        	gtk_widget_set_sensitive(botonE1, TRUE);

    // Construir la ruta completa del archivo de imagen
    char rutaImagen[100];
    snprintf(rutaImagen, sizeof(rutaImagen), "/home/lp1-2023/eclipse-workspace/GTK_2/%s", nombreImagen);

    // Actualizar la imagen
    gtk_image_set_from_file(GTK_IMAGE(imagenE1), rutaImagen);
}

void actualizarBotones(int tablero[5][5], int tableroposic[5][5], int color) {
    actualizarBotonA5(tablero, tableroposic, color);
    actualizarBotonA4(tablero, tableroposic, color);
    actualizarBotonA3(tablero, tableroposic, color);
    actualizarBotonA2(tablero, tableroposic, color);
    actualizarBotonA1(tablero, tableroposic, color);
    actualizarBotonB5(tablero, tableroposic, color);
    actualizarBotonB4(tablero, tableroposic, color);
    actualizarBotonB3(tablero, tableroposic, color);
    actualizarBotonB2(tablero, tableroposic, color);
    actualizarBotonB1(tablero, tableroposic, color);
    actualizarBotonC5(tablero, tableroposic, color);
    actualizarBotonC4(tablero, tableroposic, color);
    actualizarBotonC3(tablero, tableroposic, color);
    actualizarBotonC2(tablero, tableroposic, color);
    actualizarBotonC1(tablero, tableroposic, color);
    actualizarBotonD5(tablero, tableroposic, color);
    actualizarBotonD4(tablero, tableroposic, color);
    actualizarBotonD3(tablero, tableroposic, color);
    actualizarBotonD2(tablero, tableroposic, color);
    actualizarBotonD1(tablero, tableroposic, color);
    actualizarBotonE5(tablero, tableroposic, color);
    actualizarBotonE4(tablero, tableroposic, color);
    actualizarBotonE3(tablero, tableroposic, color);
    actualizarBotonE2(tablero, tableroposic, color);
    actualizarBotonE1(tablero, tableroposic, color);

}

gboolean ejecutarActualizaciones(gpointer data){
	actualizarBotones(tablero, tableroposic, color);
	flag=FindelJuego();
	return FALSE;
}

// no recuerdo para que usaba
void hide_and_destroy_if_valid(GtkWidget *widget) {
    if (GTK_IS_WIDGET(widget) && gtk_widget_get_visible(widget)) {
        gtk_widget_destroy(widget);
    }
}
