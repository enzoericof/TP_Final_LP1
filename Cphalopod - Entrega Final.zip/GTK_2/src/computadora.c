#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include <glib.h>
#include <time.h> //librería necesaria para generar números aleatorios
#include "constantes.h"
#include "tablero.h"
#include "GTK_2.h"
//extern GtkBuilder *builder;
extern int color;
extern int tablero[TAM_TABLERO][TAM_TABLERO];
extern int matrizcapturas[4][3];
extern int posiblescapturas;
extern int tableroposic[TAM_TABLERO][TAM_TABLERO];



//revisa si la casilla está libre para la computadora. 1 si está, 0 si no
int libreCompu (int coordX, int coordY){
    if (tablero[(5-coordY)][coordX-1]==0){
        return 1;}
    return 0;
}

// Función para evaluar la captura de dados del rival
int evaluarCaptura(int x, int y, int player, int tablero[TAM_TABLERO][TAM_TABLERO], int tableroposic[TAM_TABLERO][TAM_TABLERO]){
	int captura = 0;
	    int dx[] = {0, 0, -1, 1}; // Up, Down, Left, Right
	    int dy[] = {-1, 1, 0, 0};

	    // Verificar la captura en la posición actual
	    if (tableroposic[5-y][x-1] == 7) {
	        // Verificar capturas en las cuatro direcciones adyacentes
	        for (int dir = 0; dir < 4; dir++) {
	            int nx = x + dx[dir];
	            int ny = y + dy[dir];

	            if (nx >= 0 && nx < TAM_TABLERO && ny >= 0 && ny < TAM_TABLERO &&
	                tableroposic[5-ny][nx-1] == 8) {
	                captura += tablero[5-ny][nx-1];
	            }
	        }
	    }
	    printf("captura %d", captura);

	    return captura;
	}
// Función para estrategia de captura mejorada
int* estrategiaCapturaMejorada(int tableroposic[TAM_TABLERO][TAM_TABLERO], int tablero[TAM_TABLERO][TAM_TABLERO]) {
	static int compuJugada[2];
	    int mejorCaptura = 0;
	    //int dx[] = {-1, -1, 1, 1}; // Up-Left, Up-Right, Down-Left, Down-Right
	    //int dy[] = {-1, 1, -1, 1};

	    for (int x = 0; x < TAM_TABLERO; x++) {
	        for (int y = 0; y < TAM_TABLERO; y++) {
	            if (tableroposic[5-y][x-1] == 8) {  // Dados de la computadora
	                // Dado de la computadora encontrado en la posición (x, y)
	                int capturaActual = evaluarCaptura(x, y, 7, tablero, tableroposic);  // Cambiado a 8 para representar los dados de la compu

	                if (capturaActual > mejorCaptura && libreCompu(x, y)==1) {
	                    mejorCaptura = capturaActual;
	                    compuJugada[0] = x;
	                    compuJugada[1] = y;
	                }
	            }
	        }
	    }

	    // Si no hay una posición estratégica al principio, buscar entre los dados rivales
	    if (mejorCaptura == 0) {
	    	int maxDadosRivales = 0;

	    	    for (int x = 0; x < TAM_TABLERO; x++) {
	    	        for (int y = 0; y < TAM_TABLERO; y++) {
	    	            if (tableroposic[5-y][x-1] == 7) {  // Dados del jugador rival
	    	                // Evaluar cantidad de dados rivales adyacentes en esta posición
	    	                int dadosRivalesAdyacentes = evaluarCaptura(x, y, 7, tablero, tableroposic);

	    	                // Actualizar la posición con más dados rivales adyacentes si es necesario
	    	                if (dadosRivalesAdyacentes > maxDadosRivales && libreCompu(x, y)==1) {
	    	                    maxDadosRivales = dadosRivalesAdyacentes;
	    	                    compuJugada[0] = x;
	    	                    compuJugada[1] = y;
	    	                }
	    	            }
	    	        }
	    	    }
	    	}

	    printf("jugada compu 1 %d, %d", compuJugada[0], compuJugada[1]);
	   return compuJugada;
	}
//pide a la computadora una jugada aleatoria y valida si la casilla está libre
int* pedirJugadaCompu (void){
	int ret;
	    static int compuJugada[2];

	    // Buscar una jugada de captura mejorada
	    int* resultArray = estrategiaCapturaMejorada(tableroposic, tablero);
	    compuJugada[0] = resultArray[0];
	    compuJugada[1] = resultArray[1];

	    if (compuJugada[0] != 0 && compuJugada[1] != 0) {
	        return compuJugada;
	    }
	    else if (compuJugada[0] == 0 && compuJugada[1] == 0) {
	        for (int x = 0; x < TAM_TABLERO; x++) {
	            for (int y = 0; y < TAM_TABLERO; y++) {
	                if (tableroposic[TAM_TABLERO - y][x - 1] == 7) {
	                    // Intentar ubicarse en las casillas adyacentes
	                    if (x > 1 && libreCompu(x - 1, y) == 1) {
	                        compuJugada[0] = x - 1;
	                        compuJugada[1] = y;
	                        return compuJugada;
	                    }
	                    if (x < TAM_TABLERO && libreCompu(x + 1, y) == 1) {
	                        compuJugada[0] = x + 1;
	                        compuJugada[1] = y;
	                        return compuJugada;
	                    }
	                    if (y > 1 && libreCompu(x, y - 1) == 1) {
	                        compuJugada[0] = x;
	                        compuJugada[1] = y - 1;
	                        return compuJugada;
	                    }
	                    if (y < TAM_TABLERO && libreCompu(x, y + 1) == 1) {
	                        compuJugada[0] = x;
	                        compuJugada[1] = y + 1;
	                        return compuJugada;
	                    }
	                }
	            }
	        }
	    }

	    // Si no hay una jugada adyacente, realizar una jugada aleatoria
	    do {
	       srand(time(NULL));
	       compuJugada[0]=1+rand()%(5-1+1); //inferior + rand()%(superior+1-inferior)
	       compuJugada[1]=1+rand()%(5-1+1);
	       ret=libreCompu(compuJugada[0], compuJugada[1]);
	       } while (ret!=1);

	    printf("jugada compu %d, %d", compuJugada[0], compuJugada[1]);
	    return compuJugada;
	}
//pide a la computadora una jugada aleatoria y valida si la casilla está libre


//turno de la compu
void turnoCompu (int jugador, int color){
	if (color==2){
        RED;printf("\nTURNO DE LA COMPUTADORA\n");BLA;
    }
    if (color==1){
        BLUE;printf("\nTURNO DE LA COMPUTADORA\n");BLA;
    }


    int suma=0;
    int *punteroCompu;
    punteroCompu=pedirJugadaCompu();
    if (*punteroCompu==1 || *punteroCompu==5 || *(punteroCompu+1)==1 || *(punteroCompu+1)==5)
        contadorCapturasLados(tablero, *punteroCompu, *(punteroCompu+1));
    if (*punteroCompu!=1 && *punteroCompu!=5 && *(punteroCompu+1)!=1 && *(punteroCompu+1)!=5)
       contadorCapturasMedio(tablero, *punteroCompu, *(punteroCompu+1));
    if ((*punteroCompu==1 && *(punteroCompu+1)==5) || (*punteroCompu==5 && *(punteroCompu+1)==5) || (*punteroCompu==5 && *(punteroCompu+1)==1) || (*punteroCompu==1 && *(punteroCompu+1)==1))
        contadorCapturasEsquinas(tablero, *punteroCompu, *(punteroCompu+1));
    if (posiblescapturas<2){
        tablero[5-*(punteroCompu+1)][*punteroCompu-1]=1;
    }
    if (posiblescapturas==2){
        for (int i=0;i<4;i++){
            if (matrizcapturas[i][0]==1){
                suma=suma+tablero[5-(matrizcapturas[i][2])][(matrizcapturas[i][1]-1)];
            }
        }
        if (suma>6){
            tablero[5-*(punteroCompu+1)][*punteroCompu-1]=1;
        }
        else{
            tablero[5-*(punteroCompu+1)][*punteroCompu-1]=suma;
            for (int i=0;i<4;i++){
                if (matrizcapturas[i][0]==1){
                    tablero[5-(matrizcapturas[i][2])][(matrizcapturas[i][1]-1)]=0;
                    tableroposic[5-(matrizcapturas[i][2])][(matrizcapturas[i][1]-1)]=0;
                }
            }
        }
    }
    if (posiblescapturas>2){//acá hay un error de lógica, podes comer 0 y 1 casillas
        int ret2;
        int matrizauxiliar[4][3];
        do {
            suma=0;
            for (int j=0;j<4;j++){
                for (int k=0;k<3;k++){
                    matrizauxiliar[j][k]=matrizcapturas[j][k];
                }
            }
            for (int i=0;i<4;i++){
                if (matrizcapturas[i][0]==1){
                    srand(time(NULL));
                    ret2=1;
                    if (ret2==1){
                        matrizauxiliar[i][0]=2;
                        suma=suma+tablero[(5-matrizcapturas[i][2])][matrizcapturas[i][1]-1];
                    }
                }
            }
        } while (suma>6);
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 3; j++) {
            printf("%d\t", matrizauxiliar[i][j]);
        }
        printf("\n");}
        for (int l=0;l<4;l++){
            if (matrizauxiliar[l][0]==2){
                tablero[5-(matrizcapturas[l][2])][(matrizcapturas[l][1])-1]=0;
                tableroposic[5-(matrizcapturas[l][2])][(matrizcapturas[l][1])-1]=0;
            }
        tablero[5-*(punteroCompu+1)][*punteroCompu-1]=suma;
        }
    }
    tableroPosiciones(tableroposic,8, *punteroCompu, *(punteroCompu+1));
    imprimirTablero(color);
    if (color==2){
        RED;printf("\nFIN DEL TURNO\n");BLA;
    }
    if (color==1){
        BLUE;printf("\nFIN DEL TURNO\n");BLA;
    }
    posiblescapturas=0;
    label_turno(1);
}

gboolean ejecutarTurnoCompu(gpointer data) {
    turnoCompu(8, color);
    return FALSE;
}



