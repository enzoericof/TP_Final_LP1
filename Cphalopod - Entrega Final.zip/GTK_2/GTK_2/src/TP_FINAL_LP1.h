/*
 * TP_FINAL_LP1.h
 *
 *  Created on: 12 nov. 2023
 *      Author: lp1-2023
 */

#ifndef TP_FINAL_LP1_H_
#define TP_FINAL_LP1_H_

void empiezaUsuario (int color);
void empiezaCompu (int color);
int principal();
int principalgtk(int *coordenadas, int color, int *botonaux);
int principalgtk1(int color);


#endif /* TP_FINAL_LP1_H_ */
