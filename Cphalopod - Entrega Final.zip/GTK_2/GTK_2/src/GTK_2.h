

#ifndef GTK_2_H_
#define GTK_2_H_



void deshabilitar_botones_tablero(GtkBuilder *builder);
void activar_botones(int matrizcapturas[4][3]);
void label_turno(int num);
void actualizarBotonA5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonA4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonA3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonA2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonA1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonB1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonC1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonD1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE5(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE4(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE3(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE2(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotonE1(int tablero[5][5], int tableroposic[5][5], int color);
void actualizarBotones(int tablero[5][5], int tableroposic[5][5], int color);
gboolean ejecutarActualizaciones(gpointer data);
void deshabilitar_botones_tablero(GtkBuilder *builder);



#endif /* GTK_2_H_ */
