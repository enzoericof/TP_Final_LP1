#ifndef CONSTANTES_H_
#define CONSTANTES_H_
#define RED printf("\e[0;31m") //color rojo
#define BLUE printf("\033[0;34m") //color azul
#define BLA printf("\033[0m") //color blanco
#define GREEN printf("\033[0;32m") //color verde
#define TAM_TABLERO 5


#endif /* CONSTANTES_H_ */
