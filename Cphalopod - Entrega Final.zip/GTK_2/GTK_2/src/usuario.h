/*
 * usuario.h
 *
 *  Created on: 21 oct. 2023
 *      Author: lp1-2023
 */

#ifndef USUARIO_H_
#define USUARIO_H_

int libreUsuario (int coordX, int coordY);
int* pedirJugadaUsuario (void);
void turnoUsuario (int jugador, int color, int *coordenadas, int *botonaux);
void revisioncapturas (int jugador, int color, int *coordenadas);
int buscarDuplaCoordenadas(int x, int y);

#endif /* USUARIO_H_ */
